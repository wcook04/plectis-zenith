"""Zero-inference probe and candidate-selection assay on a frozen inventory."""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sqlite3
import sys

from research import observation_candidate_pool_screen as pool
from research import observation_repair_screen as repair
from zenith.providers import digest, write_json

VERSION = 'zenith_observation_active_selection_v1'
POLICIES = ('fixed', 'disagreement')
SELECTORS = ('initial', 'reselect')
ARMS = tuple(p + '_' + s for p in POLICIES for s in SELECTORS)


def prepare(output, parent, *, seed=20261019, probe_budget=2, probe_pool_size=8, final_size=32):
    if probe_budget != 2 or not 2 <= probe_pool_size <= 16:
        raise ValueError('exactly two probes and a pool of 2..16 actions required')
    parent, output = Path(parent).resolve(), Path(output).resolve()
    old, data, frozen = repair.load_final(parent)
    if old['schema'] != pool.VERSION:
        raise ValueError('completed candidate-pool parent required')
    raw = {p.name.removesuffix('-raw.json'): repair.read(p)['content']
           for p in (parent/'responses').glob('*-raw.json')}
    prompts = {p.stem: repair.read(p) for p in (parent/'prompts').glob('*.json')}
    custody = pool.replay_records(old, data, frozen, raw, prompts)
    forbidden = {tuple(tuple(a) for a in s) for s in data['excluded_structures']}
    forbidden.update(repair.shape(a) for key in ('screen_actions', 'confirmation_actions') for a in data[key])
    targets = []
    for target, record in zip(data['targets'], frozen):
        if target['id'] != record['id']:
            raise ValueError('parent target order differs')
        slots = [s for label in pool.MODELS for s in record['arms'][label+'4']['slots']]
        if len(slots) != 8 or len({s['slot_id'] for s in slots}) != 8:
            raise ValueError('eight distinct attempt slots required')
        inventory = [{k: s[k] for k in ('slot_id', 'model_label', 'origin', 'proposal', 'response_error')}
                     for s in slots]
        targets.append({k: target[k] for k in ('id', 'source_id', 'config', 'history')} | {'inventory': inventory})
        forbidden.update(repair.shape(r['actions']) for r in target['history'])
    probes = repair.action_pool(seed, probe_pool_size, forbidden)
    final = repair.action_pool(seed+1, final_size, forbidden | {repair.shape(a) for a in probes})
    dataset = {'targets': targets, 'probe_actions': probes, 'final_actions': final,
        'excluded_structures': sorted(forbidden), 'parent_custody': custody}
    required = repair.dependencies()
    for module in (pool, sys.modules[__name__]):
        path = Path(module.__file__).resolve()
        required[str(path.relative_to(repair.ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    output.mkdir(parents=True, exist_ok=False)
    protocol = {'schema': VERSION, 'seed': seed, 'probe_budget': probe_budget, 'arms': list(ARMS),
        'dataset_sha256': digest(dataset), 'runtime_dependencies': required, 'source': repair.archive(output, required),
        'python_version': sys.version, 'sqlite_version': sqlite3.sqlite_version, 'calls': 0,
        'parent': {'protocol_sha256': digest(old), 'dataset_sha256': digest(data),
                   'frozen_sha256': digest(frozen), 'source_archive_sha256': old['source']['sha256'],
                   'models': old['models'], 'construction_replay': custody},
        'inventory_sha256': digest([t['inventory'] for t in targets]),
        'selection': old['selection_rule'],
        'probe_rule': 'Fixed: first unused pool index. Disagreement: maximum unequal pairs of valid answers, summed across three goals, then first index. Errors excluded; identical source bytes have one vote. No unchosen native labels are executed.',
        'matching': 'Eight frozen attempt slots/source in every condition. Two native probes/policy/source. Initial and reselect share identical receipt histories within each policy. Only reselect can change the initial candidate. No new inference.',
        'boundary': 'Authored disagreement and development selection, not LLM active learning. Same retrospectively selected sources and disclosed native family; no new generation, domain replication or open-world identification claim.',
        'primary': 'Supported correct resolved count and coverage on the fixed final query denominator; report supported denominator, wrong, unsupported, abstentions and errors separately. Exact family-conditional score is secondary.'}
    write_json(output/'datasets.json', dataset); write_json(output/'protocol.json', protocol)
    write_json(output/'preparation-receipt.json', {'protocol_sha256': digest(protocol), 'dataset_sha256': digest(dataset)})
    return protocol


def selection(target, history):
    chosen = pool.select(target['inventory'], repair.development(repair.WorldConfig(**target['config']), history))
    return {'selected_slot': chosen['selected_slot'], 'source_sha256':
        hashlib.sha256(chosen['champion']['source'].encode()).hexdigest(),
        'development_summary': chosen['development_summary'],
        'slots': [{'slot_id': s['slot_id'], 'development': s['development']} for s in chosen['slots']]}


def program(target, selected):
    return next((s['proposal'] for s in target['inventory'] if s['slot_id'] == selected['selected_slot']), repair.UNKNOWN)


def predictions(target, history, actions):
    """Public contexts only: never call cases, compatible, observe or native SQL."""
    contexts = [{'id': digest([target['source_id'], history, a, g]), 'source_id': target['source_id'],
        'actions': a, 'goal': g, 'documentation': repair.task_spec(), 'tables': {'history': history}}
        for a in actions for g in repair.GOALS]
    # Reuse the existing answer validator/process limits; this explicit dummy key
    # is discarded. It requires no evaluator or numerical native outcomes.
    dummy = {'value': None, 'unresolved': True}
    result = []
    for slot in target['inventory']:
        rows = repair.score(slot['proposal']['source'], [(c, dummy) for c in contexts])['rows']
        if slot.get('response_error'):
            for row in rows: row['error'] = slot['response_error']['schema_error']
        result.append({'slot_id': slot['slot_id'], 'source_sha256': hashlib.sha256(slot['proposal']['source'].encode()).hexdigest(),
                       'rows': [{k: r[k] for k in ('answer', 'error', 'trace')} for r in rows]})
    return result


def choose(policy, predicted, remaining):
    votes = list({p['source_sha256']: p for p in predicted}.values())
    values = {}
    for index in remaining:
        count = 0
        for goal in range(len(repair.GOALS)):
            answers = [p['rows'][index*len(repair.GOALS)+goal]['answer'] for p in votes
                       if p['rows'][index*len(repair.GOALS)+goal]['error'] is None]
            count += sum(a != b for a, b in itertools.combinations(answers, 2))
        values[index] = count
    if policy not in POLICIES:
        raise ValueError('unknown probe policy')
    return min(remaining, key=lambda i: (-values[i] if policy == 'disagreement' else 0, i)), values


def construct(protocol, dataset, saved=None, record_round=None):
    records, measured = [], 0
    for target_index, target in enumerate(dataset['targets']):
        config = repair.WorldConfig(**target['config'])
        initial = selection(target, target['history'])
        record = {'id': target['id'], 'initial': initial, 'policies': {}}
        for policy in POLICIES:
            history = json.loads(json.dumps(target['history'])); rounds = []; remaining = list(range(len(dataset['probe_actions'])))
            selected = initial
            for step in range(protocol['probe_budget']):
                predicted = predictions(target, history, dataset['probe_actions'])
                index, scores = choose(policy, predicted, remaining)
                if saved is None:
                    receipt = repair.observe(config, dataset['probe_actions'][index]); measured += 1
                else:
                    receipt = saved[target_index]['policies'][policy]['rounds'][step]['receipt']
                    if receipt != repair.observe(config, dataset['probe_actions'][index]):
                        raise ValueError('chosen native receipt replay differs')
                history.append(receipt); selected = selection(target, history)
                rounds.append({'step': step, 'predictions': predicted, 'disagreement_scores':
                    {str(k): v for k, v in scores.items()}, 'chosen_index': index, 'receipt': receipt,
                    'reselection': selected})
                if record_round is not None: record_round(target['id'], policy, step, rounds[-1])
                remaining.remove(index)
            record['policies'][policy] = {'rounds': rounds, 'history': history,
                                          'initial': initial, 'reselect': selected}
        records.append(record)
    return records, measured


def metrics(result):
    rows = result['rows']; valid = [r for r in rows if r['error'] is None]
    supported = [r for r in valid if not r['expected']['unresolved']]
    return {**{k: result[k] for k in ('correct', 'total', 'unsupported', 'errors')},
        'supported_queries': sum(not r['expected']['unresolved'] for r in rows),
        'supported_correct_resolved': sum(r['correct'] and not r['expected']['unresolved'] for r in valid),
        'supported_resolved': sum(not r['answer']['unresolved'] for r in supported),
        'supported_wrong_resolved': sum(not r['answer']['unresolved'] and not r['correct'] for r in supported),
        'supported_abstentions': sum(r['answer']['unresolved'] for r in supported),
        'abstentions': sum(r['answer']['unresolved'] for r in valid),
        'unsupported_queries': sum(r['expected']['unresolved'] for r in rows),
        'unsupported_abstentions': sum(r['expected']['unresolved'] and r['answer']['unresolved'] for r in valid)}


def audit(protocol, dataset, frozen):
    if len(frozen) != len(dataset['targets']) or not frozen: raise ValueError('complete nonempty frozen inventory required')
    worlds = []
    for target, record in zip(dataset['targets'], frozen):
        if target['id'] != record['id']: raise ValueError('frozen target order differs')
        row = {'id': target['id'], 'arms': {}}
        for policy in POLICIES:
            state = record['policies'][policy]
            pairs = repair.cases(repair.WorldConfig(**target['config']), state['history'], dataset['final_actions'])
            for selector in SELECTORS:
                selected = state[selector]
                result = repair.score(program(target, selected)['source'], pairs)
                row['arms'][policy+'_'+selector] = {'selection': selected['selected_slot'],
                    'metrics': metrics(result), 'result': result}
        worlds.append(row)
    aggregate = {a: {k: sum(w['arms'][a]['metrics'][k] for w in worlds)
                    for k in worlds[0]['arms'][a]['metrics']} for a in ARMS}
    for counts in aggregate.values():
        counts['supported_resolved_coverage'] = counts['supported_resolved']/counts['supported_queries'] if counts['supported_queries'] else None
        counts['supported_correct_coverage_all_queries'] = counts['supported_correct_resolved']/counts['total'] if counts['total'] else None
    return {'schema': VERSION, 'protocol_sha256': digest(protocol), 'frozen_sha256': digest(frozen),
        'worlds': worlds, 'aggregate': aggregate, 'calls': 0, 'new_reported_cost_usd': '0',
        'native_probe_measurements': len(worlds)*len(POLICIES)*protocol['probe_budget'],
        'inventory': [{'id': t['id'], 'attempt_slots': len(t['inventory']), 'distinct_sources':
            len({s['proposal']['source'] for s in t['inventory']})} for t in dataset['targets']]}


def replay_records(protocol, dataset, frozen, raw_responses=None, prompts=None):
    if raw_responses or prompts: raise ValueError('zero-inference construction has no new model responses or prompts')
    expected, _ = construct(protocol, dataset, frozen)
    if digest(expected) != digest(frozen): raise ValueError('prediction, native acquisition or selection replay differs')
    checks = sum(len(p['rows']) for r in frozen for s in r['policies'].values()
                 for step in s['rounds'] for p in step['predictions'])
    return {'exact_construction_replay': True, 'construction_checks': checks,
        'construction_check_unit': 'individual unlabelled candidate query predictions',
        'native_receipts_replayed': len(frozen)*len(POLICIES)*protocol['probe_budget'],
        'protected_evaluation_performed': False, 'calls': 0}


def run(output):
    output = Path(output)
    if (output/'started.json').exists(): raise ValueError('already started; preserve original host experiment')
    protocol, data = repair.verify(output)
    write_json(output/'started.json', {'protocol_sha256': digest(protocol), 'dataset_sha256': digest(data)})
    phase = 'acquisition'
    try:
        frozen, measured = construct(protocol, data, record_round=lambda target, policy, step, row:
            write_json(output/'probes'/f'{target}-{policy}-{step}.json', row))
        repair.verify(output)
        write_json(output/'all-frozen.json', frozen)
        write_json(output/'all-frozen-receipt.json', {'protocol_sha256': digest(protocol),
            'frozen_sha256': digest(frozen), 'construction_complete': True, 'native_probe_measurements': measured})
        phase = 'final_audit'
        result = audit(protocol, data, frozen)
        write_json(output/'results.json', result)
        return result
    except BaseException as error:
        write_json(output/'failure.json', {'phase': phase, 'error': f'{type(error).__name__}: {error}', 'calls': 0})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('prepare'); p.add_argument('output', type=Path); p.add_argument('--parent', type=Path, required=True)
    p.add_argument('--seed', type=int, default=20261019)
    p = sub.add_parser('run'); p.add_argument('output', type=Path)
    args = parser.parse_args()
    result = prepare(args.output, args.parent, seed=args.seed) if args.command == 'prepare' else run(args.output)
    print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
