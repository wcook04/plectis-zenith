"""Compare four-proposal search pools using two frozen model restart prefixes.

Mixed reuses two attempts per model; homogeneous pools add two same-model
continuations. Selection uses native development only, never old screen winners.
This is search diversity on selected failures, not learned graph composition.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import threading

from jsonschema import validate, ValidationError
from research import observation_repair_screen as repair
from zenith.budgeted import OpenRouterBudgetedProvider
from zenith.providers import digest, write_json

VERSION = 'zenith_observation_candidate_pool_v1'
MODELS = ('deepseek', 'qwen')
ARMS = ('mixed', 'deepseek4', 'qwen4')


def select(slots, pairs):
    """Maximum executable development accuracy; smallest source hash breaks ties."""
    scored = []
    for slot in slots:
        result = repair.score(slot['proposal']['source'], pairs)
        if slot.get('response_error'):
            for row in result['rows']:
                row['error'] = slot['response_error']['schema_error']
        scored.append({**slot, 'development': result})
    # adoption uses aggregate accuracy, not a per-case no-regression veto.
    # Descending hashes let neutral ties finish at the smallest source hash.
    ordered = sorted(scored, key=lambda s: (hashlib.sha256(s['proposal']['source'].encode()).hexdigest(), s['slot_id']), reverse=True)
    champion, best, chosen = dict(repair.UNKNOWN), repair.score(repair.UNKNOWN['source'], pairs), None
    for slot in ordered:
        accepted, _ = repair.adoption(best, slot['development'])
        if accepted:
            champion, best, chosen = slot['proposal'], slot['development'], slot['slot_id']
    return {'champion': champion, 'selected_slot': chosen, 'slots': scored,
            'development_summary': {k: best[k] for k in ('correct', 'total', 'errors')}}


def prepare(output, deepseek, qwen, *, seed=20261018, pool_size=16, confirmation_size=32,
            max_cost_usd='0.50'):
    output = Path(output).resolve(); output.mkdir(parents=True, exist_ok=False)
    inputs, models, datasets = {}, {}, []
    for label, path in zip(MODELS, (deepseek, qwen)):
        path = Path(path).resolve()
        protocol, data, frozen = repair.load_final(path)
        assert len(frozen) == 3, 'exactly three shared failure seeds required'
        inputs[label] = {'path': str(path), 'protocol_sha256': digest(protocol),
                         'frozen_sha256': digest(frozen), 'results_sha256': hashlib.sha256((path/'results.json').read_bytes()).hexdigest()}
        models[label] = {k: protocol[k] for k in ('model', 'provider_slug', 'reasoning_effort', 'max_output_tokens')}
        datasets.append(data)
        inputs[label]['restart_prefixes'] = [copy.deepcopy(record['arms']['restart']) for record in frozen]
    if digest(datasets[0]) != digest(datasets[1]):
        raise ValueError('parent native evidence and pools differ')
    if models['deepseek']['max_output_tokens'] != models['qwen']['max_output_tokens']:
        raise ValueError('matched output allowances required')
    targets = copy.deepcopy(datasets[0]['targets'])
    old = repair.read(Path(deepseek)/'protocol.json')
    ancestor = repair.read(Path(old['parent'])/'datasets.json')
    forbidden = set()
    for stream in ancestor['public']['streams']:
        forbidden.update(repair.shape(r['actions']) for r in stream['receipts'])
        for partition in stream['partitions'].values():
            forbidden.update(repair.shape(a) for a in partition)
    for data in datasets:
        for key in ('screen_actions', 'confirmation_actions'):
            forbidden.update(repair.shape(a) for a in data[key])
        for target in data['targets']:
            forbidden.update(repair.shape(r['actions']) for r in target['history'])
            forbidden.update(repair.shape(t['actions']) for t in target['diagnostic']['reduction_trials'])
    screen = repair.action_pool(seed, pool_size, forbidden)
    confirmation = repair.action_pool(seed + 1, confirmation_size, forbidden | {repair.shape(a) for a in screen})
    reused = []
    for label in MODELS:
        parent = Path(inputs[label]['path'])
        for index, prefix in enumerate(inputs[label]['restart_prefixes']):
            assert len(prefix['rounds']) == 2, 'exact two original restart attempts required'
            for step, entry in enumerate(prefix['rounds']):
                node = f'{targets[index]["id"]}-restart-{step}'
                raw_path = parent/'responses'/f'{node}-raw.json'
                api = [repair.read(p) for p in (parent/'handoff/api_calls/openrouter_budgeted').glob('*.json')]
                call = next(r for r in api if r['node_id'] == node)
                assert call['provider_receipt']['response_text'] == repair.read(raw_path)['content']
                reused.append({'target': targets[index]['id'], 'model_label': label, 'step': step,
                    'entry': entry, 'raw_response_sha256': hashlib.sha256(raw_path.read_bytes()).hexdigest(),
                    'provider_call_id': call['call_id'], 'provider_response_sha256': call['response_sha256'],
                    'parent_starting_program_sha256': targets[index]['parent_program_sha256']})
    dataset = {'targets': targets, 'screen_actions': screen, 'confirmation_actions': confirmation,
               'inputs': inputs, 'reused': reused}
    write_json(output/'datasets.json', dataset)
    required = repair.dependencies()
    relative = str(Path(__file__).resolve().relative_to(repair.ROOT))
    required[relative] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    protocol = {'schema': VERSION, 'seed': seed, 'models': models, 'max_calls': 12,
        'max_cost_usd': str(max_cost_usd), 'max_output_tokens': models['deepseek']['max_output_tokens'],
        'dataset_sha256': digest(dataset), 'runtime_dependencies': required,
        'source': repair.archive(output, required), 'python_version': sys.version,
        'sqlite_version': sqlite3.sqlite_version,
        'proposal_pools': 'mixed=original two DeepSeek plus original two Qwen; each homogeneous=its original two plus two new same-model continuations. Every pool has four proposal slots/source.',
        'selection_rule': 'Executable candidate with maximum native development-correct; ties choose smallest source SHA256, then smallest slot ID for identical source bytes. No protected outcomes, manual edits or best-old-screen routing.',
        'accounting': {'new_calls': 12, 'reused_unique_calls': 12, 'pool_slot_references': 36,
                       'previous_parent_campaign_calls': 36},
        'selection_boundary': 'Selected V5 failures; shared historical prefixes and differing generation histories/new-versus-old calls. This tests search diversity, not independent trials, zero-cost diversity, learned graph composition or general model superiority.',
        'confirmation_boundary': 'One explicit pool choice committed before untouched new-structure evaluation; conditional local validation on these selected sources.'}
    write_json(output/'protocol.json', protocol)
    write_json(output/'preparation-receipt.json', {'protocol_sha256': digest(protocol), 'dataset_sha256': digest(dataset)})
    return protocol


def audit(protocol, dataset, frozen, partition='screen'):
    result = repair.audit(protocol, dataset, frozen, partition)
    result['schema'] = VERSION
    result['accounting'] = protocol['accounting']
    return result


def run(output, env_file=None, *, providers=None):
    output = Path(output).resolve()
    if (output/'started.json').exists():
        raise ValueError('already started; preserve attempts')
    protocol, dataset = repair.verify(output)
    if providers is None:
        from system.lib.openrouter_free_runtime import load_env_file
        load_env_file(Path(env_file)); providers = {}
        for label, model in protocol['models'].items():
            providers[label] = OpenRouterBudgetedProvider(output/(output.name+'-'+label), model['model'],
                protocol['max_cost_usd'], 12, protocol['max_output_tokens'], output/'budget',
                provider_slug=model['provider_slug'], inference_mode='bounded')
    write_json(output/'started.json', {'protocol_sha256': digest(protocol)})
    stopped, frozen = threading.Event(), []
    try:
        for index, target in enumerate(dataset['targets']):
            pairs = repair.development(repair.WorldConfig(**target['config']), target['history'])
            slots = {label: [] for label in MODELS}
            for label in MODELS:
                state = copy.deepcopy(dataset['inputs'][label]['restart_prefixes'][index])
                for step, entry in enumerate(state['rounds']):
                    slots[label].append({'slot_id': f'{label}-{step}', 'model_label': label,
                        'origin': 'reused', 'proposal': entry['proposal'], 'response_error': entry.get('response_error')})
                for step in (2, 3):
                    repair.verify(output)
                    old = repair.score(state['champion']['source'], pairs)
                    prompt = repair.prompt_for('generic', target, state, pairs, old)
                    prompt['request'] += ' Continue this model\'s own restart trajectory using its incumbent and challenger; no other model\'s source is supplied.'
                    node = f'{target["id"]}-{label}-{step}'
                    write_json(output/'prompts'/f'{node}.json', {'system': repair.LANGUAGE, 'prompt': prompt, 'schema': repair.PROGRAM_SCHEMA})
                    provider = providers[label]
                    run_id = getattr(provider, 'run_dir', output).name
                    raw = provider.ask_ai(json.dumps(prompt, ensure_ascii=False), {
                        'meta': {'session_id': run_id, 'node_id': node}, 'system_prompt': repair.LANGUAGE,
                        'reasoning_effort': protocol['models'][label]['reasoning_effort'],
                        'response_format': {'type': 'json_schema', 'json_schema': {'name': 'observation', 'strict': True, 'schema': repair.PROGRAM_SCHEMA}}}, cancel=stopped)
                    write_json(output/'responses'/f'{node}-raw.json', {'content': raw})
                    response_error = None
                    try:
                        proposal = json.loads(raw); validate(proposal, repair.PROGRAM_SCHEMA)
                        write_json(output/'responses'/f'{node}.json', proposal)
                    except (ValueError, ValidationError) as error:
                        response_error = {'raw_content': raw, 'schema_error': f'{type(error).__name__}: {error}'}
                        proposal = {'source': '', 'scope': 'Invalid response; no repair.', 'lesson': ''}
                        write_json(output/'responses'/f'{node}-invalid.json', response_error)
                    candidate = repair.score(proposal['source'], pairs)
                    if response_error:
                        for row in candidate['rows']: row['error'] = response_error['schema_error']
                    accepted, regressions = repair.adoption(old, candidate)
                    entry = {'proposal': proposal, 'accepted': accepted,
                        'unchanged': proposal['source'] == state['champion']['source'], 'regressions': regressions,
                        'candidate_summary': {k: candidate[k] for k in ('correct', 'total', 'errors')},
                        'feedback': repair.witnesses(pairs, candidate), 'response_error': response_error,
                        'old': old, 'candidate': candidate}
                    state['rounds'].append(entry)
                    if accepted: state['champion'] = proposal
                    slots[label].append({'slot_id': f'{label}-{step}', 'model_label': label,
                        'origin': 'new', 'proposal': proposal, 'response_error': response_error})
                    write_json(output/f'{target["id"]}-{label}-partial.json', state)
            pools = {'mixed': slots['deepseek'][:2] + slots['qwen'][:2],
                     'deepseek4': slots['deepseek'], 'qwen4': slots['qwen']}
            frozen.append({'id': target['id'], 'arms': {arm: select(pool, pairs) for arm, pool in pools.items()}})
        repair.verify(output)
        write_json(output/'all-frozen.json', frozen)
        write_json(output/'all-frozen-receipt.json', {'frozen_sha256': digest(frozen),
            'protocol_sha256': digest(protocol), 'construction_complete': True, 'confirmation_started': False})
        result = audit(protocol, dataset, frozen)
        if (output/'budget/budget.json').exists():
            ledger = repair.read(output/'budget/budget.json'); result['calls'] = len(ledger['entries'])
            result['cost'] = {k: ledger[k] for k in ('total_reported_cost_usd', 'total_reserved_usd')}
        write_json(output/'results.json', result); return result
    except BaseException as error:
        stopped.set()
        write_json(output/'failure.json', {'error': f'{type(error).__name__}: {error}', 'automatic_retry': False, 'confirmation_performed': False})
        raise


def confirm(output, arm):
    if arm not in ARMS: raise ValueError('unknown pool')
    output = Path(output)
    protocol, dataset, frozen = repair.load_final(output)
    selection = {'arm': arm, 'protocol_sha256': digest(protocol), 'frozen_sha256': digest(frozen),
                 'confirmation_pool_sha256': digest(dataset['confirmation_actions'])}
    with (output/'confirmation-selection.json').open('x') as handle: json.dump(selection, handle, sort_keys=True)
    chosen = [{'id': r['id'], 'arms': {arm: r['arms'][arm]}} for r in frozen]
    result = audit(protocol, dataset, chosen, 'confirmation'); result['selection'] = selection
    write_json(output/'confirmation.json', result); return result


def main():
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest='command', required=True)
    prep = sub.add_parser('prepare'); prep.add_argument('output', type=Path)
    prep.add_argument('--deepseek', type=Path, required=True); prep.add_argument('--qwen', type=Path, required=True)
    prep.add_argument('--seed', type=int, default=20261018); prep.add_argument('--max-cost-usd', default='0.50')
    prep.add_argument('--pool-size', type=int, default=16); prep.add_argument('--confirmation-size', type=int, default=32)
    execute = sub.add_parser('run'); execute.add_argument('output', type=Path); execute.add_argument('--env-file', type=Path, required=True)
    replay = sub.add_parser('replay'); replay.add_argument('output', type=Path)
    confirmation = sub.add_parser('confirm'); confirmation.add_argument('output', type=Path); confirmation.add_argument('--arm', choices=ARMS, required=True)
    args = parser.parse_args()
    if args.command == 'prepare': result = prepare(args.output, args.deepseek, args.qwen, seed=args.seed, max_cost_usd=args.max_cost_usd, pool_size=args.pool_size, confirmation_size=args.confirmation_size)
    elif args.command == 'run': result = run(args.output, args.env_file)
    elif args.command == 'confirm': result = confirm(args.output, args.arm)
    else:
        protocol, dataset, frozen = repair.load_final(args.output)
        result = audit(protocol, dataset, frozen)
        original = repair.read(args.output/'results.json')
        if digest(result) != digest({k:v for k,v in original.items() if k not in ('cost','calls')}): raise ValueError('screen replay differs')
        result = {'exact_replay': True, 'confirmation_performed': False}
    print(json.dumps({k:v for k,v in result.items() if k not in ('worlds','runtime_dependencies')}, indent=2))


if __name__ == '__main__': main()
