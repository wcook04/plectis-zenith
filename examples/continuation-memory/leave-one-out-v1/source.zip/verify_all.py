#!/usr/bin/env python3
"""Recompute source outputs, every acquisition counter and exact certificates."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run_followup import SOURCE, source_check, canonical, digest
from src.host import load_programmes
from src.residual import Interface, Teacher, learn
from run_experiment import ALPHABET, development
from evaluation.reference import OrdinaryReference, certificate


def rows(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]


def norm(value):
    return json.loads(json.dumps(value))


class TraceTeacher(Teacher):
    def __init__(self, functions):
        super().__init__(functions, ALPHABET)
        self.new_queries = []

    def ask(self, task, word):
        key = task, tuple(word)
        hit = key in self.cache
        value = super().ask(task, tuple(word))
        if not hit:
            self.new_queries.append((task, tuple(word), int(value)))
        return value


def verify(out):
    source_check()
    result = json.loads((out / 'results.json').read_text())
    v2 = result['schema'].endswith('_v2')
    protocol_name = 'protocol-v2.json' if v2 else 'protocol.json'
    protocol = json.loads((ROOT / protocol_name).read_text())
    start = json.loads((out / 'execution-start.json').read_text())
    assert result['status'] == 'complete'
    assert result['protocol_sha256'] == start['protocol_sha256'] == hashlib.sha256((ROOT / protocol_name).read_bytes()).hexdigest()
    assert protocol['written_at'] < start['started_at']
    assert [c['condition' if v2 else 'ordering'] for c in result['cases']] == protocol['conditions' if v2 else 'orderings']
    functions = load_programmes(SOURCE)
    configs = {r['id']: r['config'] for r in json.loads((SOURCE / 'evaluation/oracle_configs.json').read_text())}
    hashes = {r['id']: r['source_sha256'] for r in json.loads((SOURCE / 'archive/programmes.json').read_text())}
    stages = []

    def stage(folder, prior_rows):
        receipt = json.loads((folder / 'receipt.json').read_text())
        binding = json.loads((folder / 'prior-cache-binding.json').read_text())
        mapping = {int(k): v for k, v in receipt['local_to_original'].items()}
        assert binding['rows'] == receipt['prior_cache_rows'] == len(prior_rows)
        assert binding['sha256'] == receipt['prior_cache_sha256'] == digest(prior_rows)
        prior = {(r['local_teacher'], tuple(r['word'])): r['value'] for r in prior_rows}
        cache = dict(prior)
        queries = rows(folder / 'new-teacher-queries.jsonl.gz')
        assert len(queries) == receipt['new_teacher_cost']['teacher_calls']
        assert sum(r['input_symbols'] for r in queries) == receipt['new_teacher_cost']['teacher_input_symbols']
        for index, row in enumerate(queries, 1):
            original = mapping[row['local_teacher']]
            key = row['local_teacher'], tuple(row['word'])
            assert row['index'] == index and key not in cache
            assert row['original_teacher'] == original and row['source_sha256'] == hashes[original]
            assert row['input_symbols'] == len(row['word'])
            assert functions[original](key[1]) == row['value']
            cache[key] = row['value']
        final = rows(folder / 'final-cache.jsonl.gz')
        assert len(final) == receipt['final_cache_rows'] == len(cache)
        assert digest(final) == receipt['final_cache_sha256']
        assert {(r['local_teacher'], tuple(r['word'])): r['value'] for r in final} == cache
        model = Interface.from_payload(json.loads((folder / 'model.json').read_text()))
        assert model.version == receipt['model_version']
        # Re-run the exact generic acquisition to reconstruct ALL counters,
        # including cache hits and arithmetic, and the full ordered new queries.
        teacher = TraceTeacher({j: functions[mapping[j]] for j in model.tasks})
        teacher.cache.update(prior)
        seeds = [(j, tuple(w)) for j, w in receipt['initial_tests']]
        learnt, trajectory = learn(teacher, development(), initial_tests=seeds)
        assert learnt.version == model.version
        assert norm(asdict(teacher.meter)) == receipt['new_teacher_cost']
        assert norm(trajectory) == receipt['trajectory']
        assert teacher.cache == cache
        assert teacher.new_queries == [(r['local_teacher'], tuple(r['word']), r['value']) for r in queries]
        proof = certificate(model, OrdinaryReference({j: configs[mapping[j]] for j in model.tasks}))
        assert proof['passed'] and norm(proof) == json.loads((folder / 'certificate.json').read_text())
        later = rows(folder / 'later-rows.jsonl.gz')
        correct = total = 0
        for row in later:
            assert [int(v) for v in model.predict(tuple(row['word']))] == row['predicted']
            assert [functions[mapping[j]](tuple(row['word'])) for j in model.tasks] == row['expected']
            correct += sum(a == b for a, b in zip(row['predicted'], row['expected']))
            total += len(model.tasks)
        assert len(later) == 128 and correct == total == receipt['later_correct'] == receipt['later_total']
        stages.append({'path': str(folder.relative_to(out)), 'new_teacher_queries_replayed': len(queries),
                       'all_acquisition_counters_recomputed': True, 'new_query_sequence_reproduced': True,
                       'exact_certificate_recomputed': True, 'later_native_outputs_replayed': total})
        return final

    if not v2:
        for case in result['cases']:
            folder = out / case['ordering']['id']
            prior = stage(folder / 'initial', [])
            assert all(r['local_teacher'] != 5 for r in prior)
            stage(folder / 'cache-only', prior)
            stage(folder / 'retained-tests', prior)
            stage(folder / 'fresh-all-six', [])
            assert case['cache_only']['prior_cache_sha256'] == case['retained_tests']['prior_cache_sha256']
            assert case['cache_only_lifetime_calls'] == case['initial_calls'] + case['cache_only_extension_calls']
            assert case['retained_tests_lifetime_calls'] == case['initial_calls'] + case['retained_tests_extension_calls']
            assert case['extension_calls_saved'] == case['cache_only_extension_calls'] - case['retained_tests_extension_calls']
        for module in result['ordinary_modules']:
            stage(out / 'ordinary-modules' / f"teacher-{module['original_teacher']}", [])
        assert len(stages) == 30
    else:
        old = json.loads((ROOT / 'run-v1/results.json').read_text())
        assert hashlib.sha256((ROOT / 'run-v1/results.json').read_bytes()).hexdigest() == protocol['source_results_v1_sha256']
        costs = {m['original_teacher']: m['receipt']['new_teacher_cost']['teacher_calls'] for m in old['ordinary_modules']}
        for case in result['cases']:
            declaration = case['condition']
            target = declaration['target_original_teacher']
            union = set()
            assert declaration['prior_original_teachers'] == [j for j in range(6) if j != target]
            for prior in declaration['prior_models']:
                raw = (ROOT / prior['relative_model_path']).read_bytes()
                assert prior['original_teacher'] != target and hashlib.sha256(raw).hexdigest() == prior['sha256']
                union.update(tuple(w) for _, w in json.loads(raw)['tests'])
            ordered = sorted(union, key=lambda w: (len(w), w))
            assert [list(w) for w in ordered] == declaration['all_acquired_unique_suffixes']
            assert declaration['warm_seeds'] == declaration['generic_seeds'] + [[target, list(w)] for w in ordered if w not in [(),(-8,)]]
            folder = out / declaration['id']
            stage(folder / 'generic', [])
            stage(folder / 'transferred-suffixes', [])
            assert case['generic']['initial_tests'] == declaration['generic_seeds']
            assert case['transferred_suffixes']['initial_tests'] == declaration['warm_seeds']
            prior_cost = sum(costs[j] for j in declaration['prior_original_teachers'])
            assert prior_cost == declaration['prior_module_teacher_calls'] == case['prior_module_calls']
            assert case['generic_target_calls'] == costs[target]
            assert case['generic_lifetime_calls'] == prior_cost + case['generic_target_calls'] == 3071
            assert case['transferred_lifetime_calls'] == prior_cost + case['transferred_target_calls']
            assert case['target_calls_saved'] == case['generic_target_calls'] - case['transferred_target_calls']
        assert len(stages) == 12
    audit = {'status': 'passed', 'protocol_sha256': result['protocol_sha256'], 'stages': stages,
             'acquisitions_fully_reproduced': len(stages), 'exact_certificates_recomputed': len(stages),
             'new_teacher_queries_replayed': sum(s['new_teacher_queries_replayed'] for s in stages),
             'later_native_outputs_replayed': sum(s['later_native_outputs_replayed'] for s in stages),
             'verification_source_execution_boundary': 'Ledger replay plus full acquisition reproduction and later native outputs are additional audit executions, excluded from original study acquisition costs.',
             'boundary': 'All counters, every new query, full source/cache custody and reference certificates recomputed; correlated conditions, not independent tasks.'}
    (out / 'replay-verification.json').write_text(json.dumps(audit, indent=2, sort_keys=True) + '\n')
    print(canonical({k: v for k, v in audit.items() if k != 'stages'}), flush=True)
    return audit


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    verify(parser.parse_args().out.resolve())
