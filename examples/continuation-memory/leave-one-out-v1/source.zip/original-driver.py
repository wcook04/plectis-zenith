#!/usr/bin/env python3
"""Predeclared six-ordering matched-cache continuation test; offline stdlib only.

Adapter around unmodified Zenith ADVANCE08 learner and archived programs.
No source-family configurations are supplied to the generic learner.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import platform
import socket
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
sys.path.insert(0, str(SOURCE))


def denied(*args, **kwargs):
    raise RuntimeError('Network prohibited in this offline follow-up')


socket.socket = denied
socket.create_connection = denied
socket.getaddrinfo = denied

from src.host import load_programmes
from src.residual import Teacher, Interface, learn
from run_experiment import ALPHABET, development, later_words
from evaluation.reference import OrdinaryReference, certificate, oracle
from evaluation.controls import fit_disclosed_family


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def source_check():
    manifest = json.loads((ROOT / 'source-manifest.json').read_text())
    for row in manifest['files']:
        raw = (SOURCE / row['path']).read_bytes()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('source snapshot changed: ' + row['path'])
    return manifest


def cache_rows(cache, mapping):
    return [{'local_teacher': j, 'original_teacher': mapping[j],
             'word': list(word), 'value': value}
            for (j, word), value in sorted(cache.items())]


class LoggedTeacher(Teacher):
    def __init__(self, functions, mapping, source_hashes, stream):
        super().__init__(functions, ALPHABET)
        self.mapping = mapping
        self.source_hashes = source_hashes
        self.stream = stream

    def ask(self, task, word):
        word = tuple(word)
        already_measured = (task, word) in self.cache
        value = super().ask(task, word)
        if not already_measured:
            original = self.mapping[task]
            row = {'index': self.meter.teacher_calls, 'local_teacher': task,
                   'original_teacher': original, 'source_sha256': self.source_hashes[original],
                   'word': list(word), 'value': int(value), 'input_symbols': len(word)}
            self.stream.write((canonical(row) + '\n').encode())
        return value


def acquire(folder, functions, mapping, source_hashes, seeds, prior, configs, words):
    folder.mkdir(parents=True, exist_ok=False)
    prior_rows = cache_rows(prior, mapping)
    dump(folder / 'prior-cache-binding.json', {
        'rows': len(prior), 'sha256': digest(prior_rows),
        'local_to_original': mapping, 'initial_tests': [[j, list(w)] for j, w in seeds]})
    teacher = None
    started = time.perf_counter()
    try:
        with gzip.GzipFile(filename=str(folder / 'new-teacher-queries.jsonl.gz'), mode='wb', mtime=0) as stream:
            teacher = LoggedTeacher(functions, mapping, source_hashes, stream)
            teacher.cache.update(prior)
            model, trajectory = learn(teacher, words, initial_tests=seeds)
        fitting_seconds = time.perf_counter() - started
        dump(folder / 'model.json', model.payload())
        # Decode the exact saved interface rather than continue a mutable fit object.
        model = Interface.from_payload(json.loads((folder / 'model.json').read_text()))
        final_rows = cache_rows(teacher.cache, mapping)
        with gzip.GzipFile(filename=str(folder / 'final-cache.jsonl.gz'), mode='wb', mtime=0) as stream:
            for row in final_rows:
                stream.write((canonical(row) + '\n').encode())
        verification_start = time.perf_counter()
        reference = OrdinaryReference(configs)
        proof = certificate(model, reference)
        dump(folder / 'certificate.json', proof)
        later = later_words()[-128:]
        correct = total = 0
        later_rows = []
        for word in later:
            predicted = model.predict(word)
            expected = tuple(oracle(configs[j], word) for j in model.tasks)
            counts = sum(a == b for a, b in zip(predicted, expected))
            correct += counts
            total += len(model.tasks)
            later_rows.append({'word': list(word), 'predicted': [int(v) for v in predicted],
                               'expected': list(expected), 'correct': counts})
        with gzip.GzipFile(filename=str(folder / 'later-rows.jsonl.gz'), mode='wb', mtime=0) as stream:
            for row in later_rows:
                stream.write((canonical(row) + '\n').encode())
        verification_seconds = time.perf_counter() - verification_start
        result = {'status': 'passed' if proof['passed'] and correct == total else 'failed_validation',
                  'local_to_original': mapping, 'tasks': list(model.tasks), 'dimension': model.dimension,
                  'initial_tests': [[j, list(w)] for j, w in seeds],
                  'prior_cache_rows': len(prior), 'prior_cache_sha256': digest(prior_rows),
                  'final_cache_rows': len(teacher.cache), 'final_cache_sha256': digest(final_rows),
                  'new_teacher_cost': asdict(teacher.meter), 'trajectory': trajectory,
                  'model_version': model.version, 'certificate_passed': proof['passed'],
                  'certificate_scope': proof['proof_scope'], 'later_correct': correct, 'later_total': total,
                  'fitting_seconds': fitting_seconds, 'verification_seconds': verification_seconds}
        dump(folder / 'receipt.json', result)
        if result['status'] != 'passed':
            raise RuntimeError('certificate or later validation failed')
        return result, model, dict(teacher.cache)
    except Exception as exc:
        dump(folder / 'failure.json', {'error': type(exc).__name__ + ': ' + str(exc),
                                      'partial_teacher_cost': asdict(teacher.meter) if teacher else None,
                                      'elapsed_seconds': time.perf_counter() - started})
        raise


def run(out):
    protocol_bytes = (ROOT / 'protocol.json').read_bytes()
    protocol = json.loads(protocol_bytes)
    manifest = source_check()
    if hashlib.sha256((ROOT / 'source-manifest.json').read_bytes()).hexdigest() != protocol['source_manifest_sha256']:
        raise ValueError('protocol source manifest mismatch')
    out = out.resolve()
    if out == SOURCE or SOURCE in out.parents or out == ROOT:
        raise ValueError('output must be a separate absent folder')
    if out.exists():
        raise ValueError('output folder already exists; never overwrite an attempt')
    out.mkdir(parents=True)
    source_hashes = {r['id']: r['source_sha256'] for r in protocol['archived_original_programs']}
    functions = load_programmes(SOURCE)
    original_configs = {row['id']: row['config'] for row in json.loads((SOURCE / 'evaluation/oracle_configs.json').read_text())}
    words = development()
    started = time.perf_counter()
    dump(out / 'execution-start.json', {
        'started_at': datetime.now(timezone.utc).isoformat(), 'protocol_sha256': hashlib.sha256(protocol_bytes).hexdigest(),
        'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_manifest_sha256': protocol['source_manifest_sha256'],
        'python_version': platform.python_version(), 'model_calls': 0,
        'development_words_sha256': digest(words), 'later_words_sha256': digest(later_words()[-128:]),
        'later_panel_boundary': 'Previously authored original panel, read-only later use; not independent confirmation.'})
    cases = []
    for ordering in protocol['orderings']:
        case = {'ordering': ordering, 'status': 'pending'}
        folder = out / ordering['id']
        folder.mkdir()
        mapping = {int(k): v for k, v in ordering['local_to_original'].items()}
        remapped_functions = {j: functions[original] for j, original in mapping.items()}
        remapped_configs = {j: original_configs[original] for j, original in mapping.items()}
        anchor = (0, (ALPHABET[0],))
        initial_seeds = [(j, ()) for j in range(5)] + [anchor]
        generic_seeds = [(j, ()) for j in range(6)] + [anchor]
        try:
            initial, v1, prior = acquire(folder / 'initial', {j: remapped_functions[j] for j in range(5)},
                                         mapping, source_hashes, initial_seeds, {},
                                         {j: remapped_configs[j] for j in range(5)}, words)
            if any(j == 5 for j, word in prior):
                raise AssertionError('sixth teacher leaked into initial cache')
            dump(folder / 'initial-freeze.json', {
                'model_version': v1.version, 'cache_sha256': initial['final_cache_sha256'],
                'original_teacher_ids': ordering['initial_original_teacher_ids'],
                'sixth_original_teacher_not_queried': ordering['sixth_original_teacher_id'],
                'learned_continuation_tests': [[j, list(w)] for j, w in v1.tests]})
            cache_only, plain, plain_cache = acquire(folder / 'cache-only', remapped_functions, mapping,
                source_hashes, generic_seeds, dict(prior), remapped_configs, words)
            retained_seeds = list(v1.tests) + [(5, ())]
            retained, memory, memory_cache = acquire(folder / 'retained-tests', remapped_functions, mapping,
                source_hashes, retained_seeds, dict(prior), remapped_configs, words)
            if cache_only['prior_cache_sha256'] != retained['prior_cache_sha256']:
                raise AssertionError('paired caches differ')
            cold, fresh, fresh_cache = acquire(folder / 'fresh-all-six', remapped_functions, mapping,
                source_hashes, generic_seeds, {}, remapped_configs, words)
            a = initial['new_teacher_cost']['teacher_calls']
            p = cache_only['new_teacher_cost']['teacher_calls']
            m = retained['new_teacher_cost']['teacher_calls']
            c = cold['new_teacher_cost']['teacher_calls']
            case.update(status='passed', initial=initial, cache_only=cache_only, retained_tests=retained,
                        fresh_all_six=cold, initial_calls=a, cache_only_extension_calls=p,
                        retained_tests_extension_calls=m, extension_calls_saved=p-m,
                        cache_only_lifetime_calls=a+p, retained_tests_lifetime_calls=a+m,
                        fresh_all_six_calls=c, restart_both_stages_lifetime_calls=a+c,
                        retained_lifetime_minus_cold_six_calls=a+m-c,
                        initial_plus_extension_input_symbols={
                            'cache_only': initial['new_teacher_cost']['teacher_input_symbols'] + cache_only['new_teacher_cost']['teacher_input_symbols'],
                            'retained_tests': initial['new_teacher_cost']['teacher_input_symbols'] + retained['new_teacher_cost']['teacher_input_symbols']})
        except Exception as exc:
            case.update(status='failed', error=type(exc).__name__ + ': ' + str(exc))
        cases.append(case)
        dump(folder / 'summary.json', case)
        dump(out / 'partial-results.json', {'completed_conditions': len(cases), 'cases': cases})
        print(canonical({'ordering': ordering['id'], 'status': case['status'],
                         'initial': case.get('initial_calls'), 'cache_only': case.get('cache_only_extension_calls'),
                         'memory': case.get('retained_tests_extension_calls'),
                         'saved': case.get('extension_calls_saved')}), flush=True)
    # Ordinary single-teacher extraction is independent, with no sharing of
    # fitted joint matrices, test lists, cache values or family configurations.
    modules = []
    for original in range(6):
        try:
            row, model, cache = acquire(out / 'ordinary-modules' / f'teacher-{original}',
                {original: functions[original]}, {original: original}, source_hashes,
                [(original, ()), (original, (ALPHABET[0],))], {}, {original: original_configs[original]}, words)
            modules.append({'original_teacher': original, 'status': 'passed', 'receipt': row})
        except Exception as exc:
            modules.append({'original_teacher': original, 'status': 'failed', 'error': str(exc)})
    ordinary_by_id = {row['original_teacher']: row['receipt'] for row in modules if row['status'] == 'passed'}
    if len(ordinary_by_id) == 6:
        for case in cases:
            if case['status'] != 'passed':
                continue
            initial_ids = case['ordering']['initial_original_teacher_ids']
            withheld = case['ordering']['sixth_original_teacher_id']
            initial_calls = sum(ordinary_by_id[j]['new_teacher_cost']['teacher_calls'] for j in initial_ids)
            extension = ordinary_by_id[withheld]['new_teacher_cost']['teacher_calls']
            case['ordinary_separate_modules'] = {
                'initial_teacher_calls': initial_calls, 'sixth_teacher_calls': extension,
                'lifetime_teacher_calls': initial_calls+extension,
                'total_dimensions': sum(row['dimension'] for row in ordinary_by_id.values()),
                'all_certificates_passed': True, 'boundary': 'Independent ordinary models learned through the same generic algorithm; no joint memory advantage claimed over this baseline.'}
            dump(out / case['ordering']['id'] / 'summary.json', case)
    # Availability-aware control stays distinct from generic acquisition.
    calibration = json.loads((SOURCE / 'archive/calibration.json').read_text())
    family_start = time.perf_counter()
    fitted, family_cost = fit_disclosed_family(calibration, tuple(range(6)))
    if fitted != original_configs:
        raise AssertionError('public-family fit differs from evaluator')
    family_control = {'new_teacher_calls': 0, 'fitting_cost': family_cost,
                      'seconds': time.perf_counter()-family_start,
                      'boundary': 'Known-family fit from existing archived public calibration, not generic discovery or a free lifetime acquisition claim.'}
    dump(out / 'known-family-control.json', family_control)
    source_check()
    if (ROOT / 'protocol.json').read_bytes() != protocol_bytes:
        raise AssertionError('protocol changed during run')
    result = {'schema': 'zenith_continuation_memory_matched_cache_results_v1',
              'status': 'complete' if all(c['status'] == 'passed' for c in cases) and len(ordinary_by_id) == 6 else 'incomplete',
              'completed_at': datetime.now(timezone.utc).isoformat(), 'protocol_sha256': hashlib.sha256(protocol_bytes).hexdigest(),
              'model_calls': 0, 'conditions': len(cases), 'cases': cases, 'ordinary_modules': modules,
              'known_family_control': family_control, 'elapsed_seconds': time.perf_counter()-started,
              'savings_conditions': sum(c.get('extension_calls_saved', 0) > 0 for c in cases),
              'tie_conditions': sum(c.get('extension_calls_saved', 0) == 0 for c in cases if c['status'] == 'passed'),
              'regression_conditions': sum(c.get('extension_calls_saved', 0) < 0 for c in cases),
              'boundary': 'Six correlated robustness conditions over the same archived programs; post-return selected hypothesis. Continuation tests transfer; transition matrices are re-extracted. Certificates establish exact reference agreement, not arbitrary external-source truth or production generalization.'}
    dump(out / 'results.json', result)
    print(canonical({'status': result['status'], 'savings_conditions': result['savings_conditions'],
                     'ties': result['tie_conditions'], 'regressions': result['regression_conditions'],
                     'seconds': result['elapsed_seconds']}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    outcome = run(args.out)
    raise SystemExit(0 if outcome['status'] == 'complete' else 1)
