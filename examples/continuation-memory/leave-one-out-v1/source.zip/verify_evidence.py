#!/usr/bin/env python3
"""Replay recorded native outputs, matched caches and exact saved certificates."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run_followup import SOURCE, source_check, canonical, digest
from src.host import load_programmes
from src.residual import Interface
from evaluation.reference import OrdinaryReference, certificate


def read_rows(path):
    with gzip.open(path, 'rt') as stream:
        return [json.loads(line) for line in stream]


def normalized(value):
    return json.loads(json.dumps(value))


def verify(out):
    source_check()
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    result = json.loads((out / 'results.json').read_text())
    start = json.loads((out / 'execution-start.json').read_text())
    assert result['status'] == 'complete'
    assert result['protocol_sha256'] == start['protocol_sha256'] == hashlib.sha256((ROOT / 'protocol.json').read_bytes()).hexdigest()
    assert [c['ordering'] for c in result['cases']] == protocol['orderings']
    assert protocol['written_at'] < start['started_at']
    functions = load_programmes(SOURCE)
    configs = {r['id']: r['config'] for r in json.loads((SOURCE / 'evaluation/oracle_configs.json').read_text())}
    source_hashes = {r['id']: r['source_sha256'] for r in protocol['archived_original_programs']}
    stages = []

    def stage(folder, expected_prior):
        receipt = json.loads((folder / 'receipt.json').read_text())
        binding = json.loads((folder / 'prior-cache-binding.json').read_text())
        mapping = {int(k): v for k, v in receipt['local_to_original'].items()}
        assert binding['rows'] == receipt['prior_cache_rows'] == len(expected_prior)
        assert binding['sha256'] == receipt['prior_cache_sha256'] == digest(expected_prior)
        cache = {(r['local_teacher'], tuple(r['word'])): r['value'] for r in expected_prior}
        queries = read_rows(folder / 'new-teacher-queries.jsonl.gz')
        assert len(queries) == receipt['new_teacher_cost']['teacher_calls']
        assert sum(r['input_symbols'] for r in queries) == receipt['new_teacher_cost']['teacher_input_symbols']
        for index, row in enumerate(queries, 1):
            assert row['index'] == index
            original = mapping[row['local_teacher']]
            assert row['original_teacher'] == original
            assert row['source_sha256'] == source_hashes[original]
            assert row['input_symbols'] == len(row['word'])
            key = row['local_teacher'], tuple(row['word'])
            assert key not in cache
            assert functions[original](key[1]) == row['value']
            cache[key] = row['value']
        final = read_rows(folder / 'final-cache.jsonl.gz')
        assert len(final) == receipt['final_cache_rows'] == len(cache)
        assert digest(final) == receipt['final_cache_sha256']
        assert {(r['local_teacher'], tuple(r['word'])): r['value'] for r in final} == cache
        model = Interface.from_payload(json.loads((folder / 'model.json').read_text()))
        assert model.version == receipt['model_version']
        remapped = {j: configs[mapping[j]] for j in model.tasks}
        fresh_proof = certificate(model, OrdinaryReference(remapped))
        assert fresh_proof['passed']
        assert normalized(fresh_proof) == json.loads((folder / 'certificate.json').read_text())
        later = read_rows(folder / 'later-rows.jsonl.gz')
        correct = total = 0
        for row in later:
            assert [int(v) for v in model.predict(tuple(row['word']))] == row['predicted']
            assert [functions[mapping[j]](tuple(row['word'])) for j in model.tasks] == row['expected']
            correct += sum(a == b for a, b in zip(row['predicted'], row['expected']))
            total += len(model.tasks)
        assert len(later) == 128
        assert correct == total == receipt['later_correct'] == receipt['later_total']
        stages.append({'path': str(folder.relative_to(out)), 'new_teacher_queries_replayed': len(queries),
                       'input_symbols_replayed': sum(r['input_symbols'] for r in queries),
                       'exact_certificate_recomputed': True, 'later_native_outputs_replayed': total})
        return final

    for case in result['cases']:
        folder = out / case['ordering']['id']
        prior = stage(folder / 'initial', [])
        assert all(row['local_teacher'] != 5 for row in prior)
        stage(folder / 'cache-only', prior)
        stage(folder / 'retained-tests', prior)
        stage(folder / 'fresh-all-six', [])
        assert case['cache_only']['prior_cache_sha256'] == case['retained_tests']['prior_cache_sha256']
        assert case['cache_only_lifetime_calls'] == case['initial_calls'] + case['cache_only_extension_calls']
        assert case['retained_tests_lifetime_calls'] == case['initial_calls'] + case['retained_tests_extension_calls']
        assert case['extension_calls_saved'] == case['cache_only_extension_calls'] - case['retained_tests_extension_calls']
    for module in result['ordinary_modules']:
        stage(out / 'ordinary-modules' / f"teacher-{module['original_teacher']}", [])
    assert len(stages) == 30
    audit = {'status': 'passed', 'protocol_sha256': result['protocol_sha256'], 'stages': stages,
             'new_teacher_queries_replayed': sum(s['new_teacher_queries_replayed'] for s in stages),
             'exact_certificates_recomputed': len(stages),
             'later_native_outputs_replayed': sum(s['later_native_outputs_replayed'] for s in stages),
             'boundary': 'Replay verifies archived source custody, accounting, cache parity and exact agreement with the declared ordinary reference. The six conditions are correlated robustness checks.'}
    (out / 'verification.json').write_text(json.dumps(audit, indent=2, sort_keys=True) + '\n')
    print(canonical({k: v for k, v in audit.items() if k != 'stages'}), flush=True)
    return audit


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    verify(parser.parse_args().out.resolve())
