#!/usr/bin/env python3
"""V2: transfer acquired questions into one ordinary held-out module."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from run_followup import SOURCE, source_check, acquire, dump, canonical
from src.host import load_programmes
from run_experiment import development, ALPHABET


def run(out):
    source_check()
    protocol_bytes = (ROOT / 'protocol-v2.json').read_bytes()
    protocol = json.loads(protocol_bytes)
    old = json.loads((ROOT / 'run-v1/results.json').read_text())
    assert hashlib.sha256((ROOT / 'run-v1/results.json').read_bytes()).hexdigest() == protocol['source_results_v1_sha256']
    assert hashlib.sha256((ROOT / 'run-v1/verification.json').read_bytes()).hexdigest() == protocol['source_verification_v1_sha256']
    if out.exists():
        raise ValueError('new absent output folder required; never overwrite attempts')
    out.mkdir(parents=True)
    functions = load_programmes(SOURCE)
    configs = {row['id']: row['config'] for row in json.loads((SOURCE / 'evaluation/oracle_configs.json').read_text())}
    hashes = {row['id']: row['source_sha256'] for row in json.loads((SOURCE / 'archive/programmes.json').read_text())}
    start = time.perf_counter()
    dump(out / 'execution-start.json', {'started_at': datetime.now(timezone.utc).isoformat(),
         'protocol_sha256': hashlib.sha256(protocol_bytes).hexdigest(), 'model_calls': 0,
         'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    cases = []
    for declaration in protocol['conditions']:
        target = declaration['target_original_teacher']
        union = set()
        for prior in declaration['prior_models']:
            raw = (ROOT / prior['relative_model_path']).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == prior['sha256']
            model = json.loads(raw)
            assert prior['original_teacher'] != target
            union.update(tuple(w) for _, w in model['tests'])
        assert [list(w) for w in sorted(union, key=lambda w: (len(w), w))] == declaration['all_acquired_unique_suffixes']
        folder = out / declaration['id']
        folder.mkdir()
        case = {'condition': declaration, 'status': 'pending'}
        try:
            baseline_seeds = [(j, tuple(w)) for j, w in declaration['generic_seeds']]
            warm_seeds = [(j, tuple(w)) for j, w in declaration['warm_seeds']]
            assert baseline_seeds == [(target, ()), (target, (ALPHABET[0],))]
            baseline, bm, bc = acquire(folder / 'generic', {target: functions[target]}, {target: target}, hashes,
                 baseline_seeds, {}, {target: configs[target]}, development())
            warm, wm, wc = acquire(folder / 'transferred-suffixes', {target: functions[target]}, {target: target}, hashes,
                 warm_seeds, {}, {target: configs[target]}, development())
            assert baseline['prior_cache_rows'] == warm['prior_cache_rows'] == 0
            assert baseline['prior_cache_sha256'] == warm['prior_cache_sha256']
            fresh_calls = baseline['new_teacher_cost']['teacher_calls']
            warm_calls = warm['new_teacher_cost']['teacher_calls']
            original_fresh = next(r['receipt']['new_teacher_cost']['teacher_calls'] for r in old['ordinary_modules'] if r['original_teacher'] == target)
            assert fresh_calls == original_fresh
            prior_calls = declaration['prior_module_teacher_calls']
            case.update(status='passed', generic=baseline, transferred_suffixes=warm,
                prior_module_calls=prior_calls, generic_target_calls=fresh_calls,
                transferred_target_calls=warm_calls, target_calls_saved=fresh_calls-warm_calls,
                generic_lifetime_calls=prior_calls+fresh_calls,
                transferred_lifetime_calls=prior_calls+warm_calls,
                generic_target_calls_match_v1_ordinary=True)
        except Exception as exc:
            case.update(status='failed', error=type(exc).__name__ + ': ' + str(exc))
        cases.append(case)
        dump(folder / 'summary.json', case)
        print(canonical({'target': target, 'status': case['status'], 'generic': case.get('generic_target_calls'),
                         'transferred': case.get('transferred_target_calls'), 'saved': case.get('target_calls_saved')}), flush=True)
    assert (ROOT / 'protocol-v2.json').read_bytes() == protocol_bytes
    result = {'schema': 'zenith_transferred_suffix_ordinary_module_results_v2',
              'status': 'complete' if all(c['status'] == 'passed' for c in cases) else 'incomplete',
              'protocol_sha256': hashlib.sha256(protocol_bytes).hexdigest(),
              'completed_at': datetime.now(timezone.utc).isoformat(), 'cases': cases,
              'savings_conditions': sum(c.get('target_calls_saved', 0) > 0 for c in cases),
              'tie_conditions': sum(c.get('target_calls_saved', 0) == 0 for c in cases if c['status'] == 'passed'),
              'regression_conditions': sum(c.get('target_calls_saved', 0) < 0 for c in cases),
              'elapsed_seconds': time.perf_counter()-start, 'model_calls': 0,
              'boundary': 'Post-v1 exploratory six correlated target functions from same archived family. Only prior acquired suffix questions transfer; no prior outputs become target truth. Both target caches empty; all six outcomes retained. Generic learner and seed-selection wrapper are authored, not learned methods.'}
    dump(out / 'results.json', result)
    print(canonical({'status': result['status'], 'gains': result['savings_conditions'],
                     'ties': result['tie_conditions'], 'losses': result['regression_conditions']}), flush=True)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    r = run(parser.parse_args().out.resolve())
    raise SystemExit(0 if r['status'] == 'complete' else 1)
