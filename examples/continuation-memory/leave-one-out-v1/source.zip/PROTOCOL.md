# Matched continuation-memory follow-up

All six conditions below are declared before this follow-up executes. The hypothesis was chosen after reading the original return and matched-cache audit; these conditions are correlated robustness checks, not independent confirmation.

| Sixth original teacher | Initial teacher order | Full teacher order | Original anchor teacher |
|---|---|---|---|
| 0 | 1,2,3,4,5 | 1,2,3,4,5,0 | 1 |
| 1 | 0,2,3,4,5 | 0,2,3,4,5,1 | 0 |
| 2 | 0,1,3,4,5 | 0,1,3,4,5,2 | 0 |
| 3 | 0,1,2,4,5 | 0,1,2,4,5,3 | 0 |
| 4 | 0,1,2,3,5 | 0,1,2,3,5,4 | 0 |
| 5 | 0,1,2,3,4 | 0,1,2,3,4,5 | 0 |

Remap each full order to local IDs 0..5, because the existing learner sorts teacher IDs. Initial acquisition uses five empty-output tests and the first alphabet symbol (-8) on local teacher 0. Acquire initial once and clone its exact measurement cache into both extension arms. Cache-only starts with all six empty tests and the same initial anchor. Memory starts with the actual learned initial continuation tests and new teacher 5 empty test. Neither receives an extra sixth-teacher anchor or failed-readout cache.

Each condition also gets a cold fresh-all-six comparison. Learn all six ordinary single-program modules separately and count the appropriate initial five, sixth extension and lifetime totals. The original disclosed-family fitter's zero new teacher calls remain an availability boundary; it is not generic learning. Report every ordering and outcome, not just gains.

Fit against unchanged development words only. Serialize acquired models/cache before evaluation. After fitting, check exact rational reference certificates and the unchanged 128-word later panel, with no feedback into fitting. Certificates prove agreement with the declared ordinary reference, not empirical correctness of arbitrary external sources.

Teacher-query ledgers record newly executed native calls, word, value and original source identity. Both paired arms share the same initial cache hash. Report initial+extension teacher costs and separate verification/elapsed costs. Source snapshots and per-file hashes make this package reproducible with the standard library. No model/network/account operation or maintained edit is part of this follow-up.
