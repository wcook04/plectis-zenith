# Source attribution

This follow-up adapts the unmodified Zenith ADVANCE return 08 package, `ZENITH_ADVANCE_RETURN_08-abstractions-that-earn-their-keep`, and its `run_probe_followup.py` control design. The exact learner, runtime, source loader, evaluator, public calibration and six archived programs are copied under `source/`, with byte hashes and original paths in `source-manifest.json`. The original Apache2.0 LICENSE is retained at `source/LICENSE`; copied source headers and programme JSON pointers are preserved.

The driver, protocol and verifier are local follow-up additions. The matched-cache design incorporates the independent critic's `scout-06-10/audit08.py` analysis. No claimed implementation novelty follows from repackaging these files. Source-family fitting is reported as an ordinary availability-aware control and never described as generic learning.
