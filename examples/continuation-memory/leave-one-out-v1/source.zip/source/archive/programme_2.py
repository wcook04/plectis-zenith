def investigate(context, acquire):
    values = context["values"]
    n = len(values)
    if n == 0:
        return 0
    contrib = []
    for i in range(n):
        x = values[i]
        c = x - x*x*x
        if i > 0:
            c = c - 2 * x * values[i-1]
        contrib.append(c)
    for p in range(2):
        total = 0
        newc = []
        for v in contrib:
            total = total + v
            newc.append(total)
        contrib = newc
    return contrib[-1]
