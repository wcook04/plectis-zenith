def investigate(context, acquire):
    values = context["values"]
    if len(values) == 0:
        return 0
    contrib = []
    for x in values:
        contrib.append(2 * x * x * x - 2 * x * x)
    for k in range(4):
        total = 0
        next_list = []
        for v in contrib:
            total = total + v
            next_list.append(total)
        contrib = next_list
    return contrib[-1]
