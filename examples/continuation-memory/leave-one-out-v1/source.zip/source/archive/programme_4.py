def investigate(context, acquire):
    values = context["values"]
    total = 0
    prefix = 0
    for x in values:
        total = total + (2 * x * x - x * x * x) + 2 * x * prefix
        prefix = prefix + x
    return total
