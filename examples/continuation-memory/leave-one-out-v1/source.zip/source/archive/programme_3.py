def investigate(context, acquire):
    values = context["values"]
    if len(values) == 0:
        return 0
    contrib = []
    prev = 0
    for x in values:
        p = -x + 2*x*x
        term = 2*x*prev
        contrib.append(p + term)
        prev = x
    for _ in range(4):
        total = 0
        for i in range(len(contrib)):
            total = total + contrib[i]
            contrib[i] = total
    return contrib[-1]
