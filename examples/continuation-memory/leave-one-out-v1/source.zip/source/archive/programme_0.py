def investigate(context, acquire):
    total = 0
    for x in context["values"]:
        total = total + x*x*x - x
    return total
