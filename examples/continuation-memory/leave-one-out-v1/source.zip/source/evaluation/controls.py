"""Serious ordinary-library controls plus explicitly weak diagnostic ablations."""
from __future__ import annotations
from itertools import product
from fractions import Fraction as F
from src.runtime import columns,apply
from src.residual import identity
from evaluation.reference import OrdinaryReference,oracle


def family():
    for coefficients in product(range(-2,3),repeat=3):
        if coefficients==(0,0,0):continue
        for passes in range(1,5):
            yield dict(coefficients=list(coefficients),passes=passes,interaction='none',cross_coefficient=0)
            for interaction in ('adjacent','prefix'):
                for gamma in (-2,-1,1,2):
                    yield dict(coefficients=list(coefficients),passes=passes,interaction=interaction,cross_coefficient=gamma)


def fit_disclosed_family(calibration:dict,ids:tuple[int,...])->tuple[dict,dict]:
    """Receives public examples, not private configurations or target source."""
    configs={};candidates=checks=symbols=0;per_task={}
    for task in ids:
        matches=[];start_checks=checks
        for config in family():
            candidates+=1;consistent=True
            for row in calibration[str(task)]:
                word=tuple(row['input']['values']);checks+=1;symbols+=len(word)
                if oracle(config,word)!=row['expected']:
                    consistent=False;break
            if consistent:matches.append(config)
        if len(matches)!=1:raise RuntimeError('family-specific control is not uniquely identified')
        configs[task]=matches[0];per_task[task]={'consistent':len(matches),'checks':checks-start_checks}
    return configs,{'candidate_configurations':candidates,'example_checks':checks,'input_symbols':symbols,'per_task':per_task,
                    'model_calls':0,'source':'disclosed family and archived public calibration only'}


def ordinary_alternatives(reference:OrdinaryReference,prefix,alternatives,suffix)->list[tuple[int,...]]:
    """Ordinary forward-state / backward-consumer factoring. No graph object.

    Compute a suffix's action on basis states using the structured recurrence,
    avoiding matrix learning. The same two-sided optimisation is permitted here.
    """
    state=reference.state(prefix)
    projection=[]
    for basis in identity(reference.dimension):
        s=basis
        for a in suffix:s=reference.step(s,a)
        projection.append(tuple(F(s[start+depth-1]) for start,depth,mem in reference.layouts.values()))
    projected=columns(tuple(projection))
    result=[]
    for mid in alternatives:
        s=state
        for a in mid:s=reference.step(s,a)
        result.append(apply(s,projected))
    return result


def ordinary_forward(reference:OrdinaryReference,prefix,alternatives,suffix)->list[tuple[int,...]]:
    """Often faster on these tiny workloads than an elaborate suffix index."""
    state=reference.state(prefix);result=[]
    for middle in alternatives:
        s=state
        for a in middle+suffix:s=reference.step(s,a)
        result.append(tuple(s[start+depth-1] for start,depth,mem in reference.layouts.values()))
    return result
