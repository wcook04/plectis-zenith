"""Evaluator-only ordinary reference, never passed to the abstraction learner.

New implementation of the public source-family semantics. Configurations are
extracted, unchanged, from the supplied archived dataset. The binomial oracle
and streaming recurrence are independently organised. This is a strong authored
control, not evidence that a model learnt a recurrence or its own learning rule.
"""
from __future__ import annotations
from fractions import Fraction as F
from math import comb
from src.residual import Matrix, Vector, Word, RowBasis, identity, multiply, row_times


def oracle(config: dict, word: Word) -> int:
    a,b,c=config['coefficients'];depth=config['passes']
    mode=config['interaction'];g=config['cross_coefficient'];n=len(word)
    total=0
    for i,x in enumerate(word):
        previous=word[i-1] if i and mode=='adjacent' else sum(word[:i]) if mode=='prefix' else 0
        total += comb(n-i+depth-2,depth-1)*(a*x+b*x*x+c*x*x*x+g*x*previous)
    return total


class OrdinaryReference:
    """One constant plus independent running registers for each task.

    Append the public known symbol; update all repeated cumulative sums using
    their new values. State memories are intentionally unshared across tasks,
    so separate-control and joint-minimisation accounting remain transparent.
    """
    def __init__(self,configs:dict[int,dict]):
        self.configs=configs;self.tasks=tuple(sorted(configs));self.layouts={};offset=1
        for task in self.tasks:
            c=configs[task];depth=c['passes'];memory=c['interaction']!='none'
            self.layouts[task]=(offset,depth,offset+depth if memory else None)
            offset+=depth+int(memory)
        self.dimension=offset
        self.initial=tuple([1]+[0]*(offset-1))
        self.readouts=tuple(tuple(F(int(i==self.layouts[t][0]+self.layouts[t][1]-1)) for t in self.tasks)
                            for i in range(offset))

    def step(self,state:tuple,x:int)->tuple:
        s=list(state)
        for task in self.tasks:
            c=self.configs[task];a,b,cube=c['coefficients'];start,depth,mem=self.layouts[task]
            value=(a*x+b*x*x+cube*x*x*x)*s[0]
            if mem is not None:value+=c['cross_coefficient']*x*s[mem]
            for k in range(start,start+depth):
                s[k]+=value;value=s[k]
            if mem is not None:
                s[mem]=x*s[0] if c['interaction']=='adjacent' else s[mem]+x*s[0]
        return tuple(s)

    def state(self,word:Word)->tuple:
        s=self.initial
        for x in word:s=self.step(s,x)
        return s

    def predict(self,word:Word)->tuple[int,...]:
        s=self.state(word)
        return tuple(s[start+depth-1] for start,depth,mem in self.layouts.values())

    def matrix(self,x:int)->Matrix:
        return tuple(tuple(map(F,self.step(row,x))) for row in identity(self.dimension))


def certificate(model,reference:OrdinaryReference)->dict:
    """Exact intertwining identities. Induction gives equality for all words.

    It proves agreement with this reference; the source model/binding remains a
    separate obligation. It does not turn sampled source truth into a theorem.
    """
    rm={a:reference.matrix(a) for a in model.alphabet}
    cols=[]
    for task,suffix in model.tests:
        t=identity(reference.dimension)
        for a in suffix:t=multiply(t,rm[a])
        task_pos=reference.tasks.index(task)
        b=tuple((row[task_pos],) for row in reference.readouts)
        cols.append(tuple(row[0] for row in multiply(t,b)))
    transform=tuple(tuple(col[i] for col in cols) for i in range(reference.dimension))
    init=tuple(map(F,reference.initial))
    # Independently stored memories need agree only on reachable states, not on
    # impossible assignments where two copies of the same last value differ.
    rb=RowBasis(reference.dimension);queue=[init];reachable=[];cursor=0
    while cursor<len(queue):
        row=queue[cursor];cursor+=1
        if rb.add(row):
            reachable.append(row)
            queue.extend(row_times(row,rm[a]) for a in model.alphabet)
    u=tuple(reachable)
    uc=multiply(u,transform)
    initial_ok=row_times(init,transform)==model.initial
    readout_ok=multiply(uc,model.readouts)==multiply(u,reference.readouts)
    transitions={a:multiply(multiply(u,rm[a]),transform)==multiply(uc,model.transitions[a]) for a in model.alphabet}
    return {'reference_dimension':reference.dimension,'learned_dimension':model.dimension,'reachable_reference_dimension':len(reachable),
            'initial_identity':initial_ok,'readout_identity':readout_ok,
            'transition_identities':transitions,'passed':initial_ok and readout_ok and all(transitions.values()),
            'proof_scope':'all finite words over the declared alphabet; exact rational linear reference, not empirical source validity',
            'transform':[[[x.numerator,x.denominator] for x in row] for row in transform]}
