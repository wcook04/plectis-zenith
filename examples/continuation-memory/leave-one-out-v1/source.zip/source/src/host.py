"""Load the six exact archived programmes after a deliberately narrow AST audit.

This is an offline harness for these inspected, fixed files, not a sandbox for
arbitrary model code. A live integration must use Zenith's restricted executor.
"""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
from typing import Callable
from src.residual import Word


def load_programmes(root: Path) -> dict[int, Callable[[Word], int]]:
    records=json.loads((root/'archive/programmes.json').read_text())
    functions={}
    for row in records:
        path=root/row['path'];data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=row['source_sha256']:
            raise ValueError('archived code hash mismatch')
        tree=ast.parse(data)
        if any(isinstance(n,(ast.Import,ast.ImportFrom,ast.With,ast.AsyncWith,ast.ClassDef,
                            ast.Global,ast.Nonlocal,ast.Lambda,ast.While,ast.Delete,ast.Raise,
                            ast.Try,ast.Yield,ast.Await)) for n in ast.walk(tree)):
            raise ValueError('unsupported archived syntax')
        if any(isinstance(n,ast.Attribute) and n.attr!='append' for n in ast.walk(tree)):
            raise ValueError('unexpected attribute')
        if any(isinstance(n,ast.Name) and n.id.startswith('__') for n in ast.walk(tree)):
            raise ValueError('private name')
        if not all(isinstance(n,ast.FunctionDef) for n in tree.body):
            raise ValueError('top-level execution prohibited')
        safe={'len':len,'range':range,'sum':sum}
        ns={'__builtins__':safe}
        exec(compile(tree,str(path),'exec'),ns)
        fn=ns['investigate']
        functions[row['id']]=lambda w,fn=fn:fn({'values':list(w)},None)
    return functions
