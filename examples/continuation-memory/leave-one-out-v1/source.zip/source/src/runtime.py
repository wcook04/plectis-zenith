"""Small ordinary runtime and self-contained Python code generator.

Integer coordinates are answers to the learned tests. Rational coefficients are
compiled to exact integer dot products with explicit divisibility checks.
Versions prevent accidental cross-interface reuse; they do not detect silent
source drift. No graph service, inference endpoint or history replay is needed.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import lcm
from src.residual import Accounting, Interface, Matrix, Word, identity, multiply


@dataclass
class RuntimeCost:
    weighted_terms: int = 0
    exact_divisions: int = 0
    state_steps: int = 0
    projection_steps: int = 0
    version_checks: int = 0


def columns(matrix: Matrix) -> tuple:
    result=[]
    for col in zip(*matrix):
        denominator=lcm(*(v.denominator for v in col))
        terms=tuple((i,int(x*denominator)) for i,x in enumerate(col) if x)
        result.append((terms,denominator))
    return tuple(result)


def apply(values: tuple[int,...], compiled: tuple, meter: RuntimeCost | None = None) -> tuple[int,...]:
    output=[]
    for terms,denominator in compiled:
        numerator=sum(values[i]*coefficient for i,coefficient in terms)
        if denominator!=1:
            quotient,remainder=divmod(numerator,denominator)
            if remainder:
                raise ValueError('unreachable or incompatible integer state')
        else:
            quotient=numerator
        output.append(quotient)
        if meter is not None:
            meter.weighted_terms+=len(terms)
            meter.exact_divisions+=int(denominator!=1)
    return tuple(output)


@dataclass(frozen=True)
class State:
    version: str
    length: int
    values: tuple[int,...]


@dataclass(frozen=True)
class Summary:
    version: str
    length: int
    matrix: Matrix


class Runtime:
    def __init__(self,model:Interface):
        self.model=model;self.version=model.version
        if any(x.denominator!=1 for x in model.initial):
            raise ValueError('noninteger observation coordinates')
        self.transitions={a:columns(m) for a,m in model.transitions.items()}
        self.outputs=columns(model.readouts)

    def initial(self)->State:
        return State(self.version,0,tuple(int(x) for x in self.model.initial))

    def check(self,state:State,meter:RuntimeCost | None=None)->None:
        if meter is not None:meter.version_checks+=1
        if state.version!=self.version or len(state.values)!=self.model.dimension:
            raise ValueError('incompatible state version')
        if not 0<=state.length<=self.model.max_length:
            raise ValueError('invalid history length')

    def step(self,state:State,symbol:int,meter:RuntimeCost | None=None)->State:
        self.check(state,meter)
        if type(symbol) is not int or symbol not in self.transitions or state.length>=self.model.max_length:
            raise ValueError('outside source binding')
        if meter is not None:meter.state_steps+=1
        return State(self.version,state.length+1,apply(state.values,self.transitions[symbol],meter))

    def run(self,word:Word,state:State | None=None,meter:RuntimeCost | None=None)->State:
        state=self.initial() if state is None else state
        self.check(state,meter)
        for symbol in word:state=self.step(state,symbol,meter)
        return state

    def read(self,state:State,meter:RuntimeCost | None=None)->tuple[int,...]:
        self.check(state,meter)
        return apply(state.values,self.outputs,meter)

    def predict(self,word:Word,meter:RuntimeCost | None=None)->tuple[int,...]:
        return self.read(self.run(word,meter=meter),meter)

    def suffix_projection(self,suffix:Word,meter:RuntimeCost | None=None)->Matrix:
        """A consumer requirement propagated backwards through a fixed suffix."""
        if len(suffix)>self.model.max_length or any(type(a) is not int or a not in self.model.alphabet for a in suffix):
            raise ValueError('suffix outside binding')
        result=self.model.readouts
        for symbol in reversed(suffix):
            if meter is not None:meter.projection_steps+=1
            # A projection is not generally integer valued on unit-basis states;
            # therefore compile its columns without claiming intermediate truth.
            result=multiply(self.model.transitions[symbol],result)
        return result

    def alternatives(self,prefix:Word,alternatives:tuple[Word,...],suffix:Word,
                     meter:RuntimeCost | None=None)->list[tuple[int,...]]:
        if any(len(prefix)+len(mid)+len(suffix)>self.model.max_length for mid in alternatives):
            raise ValueError('composed request outside binding')
        state=self.run(prefix,meter=meter)
        projection=columns(self.suffix_projection(suffix,meter))
        return [apply(self.run(mid,state,meter).values,projection,meter) for mid in alternatives]

    def summary(self,word:Word,algebra_cost:Accounting | None=None)->Summary:
        if len(word)>self.model.max_length or any(type(a) is not int or a not in self.model.alphabet for a in word):
            raise ValueError('chunk outside binding')
        matrix=identity(self.model.dimension)
        for a in word:matrix=multiply(matrix,self.model.transitions[a],algebra_cost)
        return Summary(self.version,len(word),matrix)

    def compose(self,left:Summary,right:Summary,algebra_cost:Accounting | None=None)->Summary:
        if left.version!=self.version or right.version!=self.version:
            raise ValueError('incompatible summary version')
        if left.length+right.length>self.model.max_length:
            raise ValueError('composition outside binding')
        return Summary(self.version,left.length+right.length,multiply(left.matrix,right.matrix,algebra_cost))

    def apply_summary(self,state:State,summary:Summary,meter:RuntimeCost | None=None)->State:
        self.check(state,meter)
        if summary.version!=self.version or state.length+summary.length>self.model.max_length:
            raise ValueError('incompatible summary or scope')
        return State(self.version,state.length+summary.length,apply(state.values,columns(summary.matrix),meter))


def compile_inline(model:Interface)->str:
    """Emit one self-contained ordinary module. No model objects at serving time."""
    def expression(terms):
        return ' + '.join(f'({c}) * state[{i}]' for i,c in terms) or '0'
    def lines_for(compiled,indent='    '):
        lines=[]
        for j,(terms,denom) in enumerate(compiled):
            lines.append(f'{indent}v{j} = {expression(terms)}')
            if denom!=1:
                lines.extend([f'{indent}if v{j} % {denom}: raise ValueError("incompatible state")',
                              f'{indent}v{j} //= {denom}'])
        vals=', '.join(f'v{j}' for j in range(len(compiled)))
        lines.append(f'{indent}return ({vals},)')
        return lines
    lines=['"""Generated from measured interface; ordinary code, no graph runtime."""',
           f'VERSION = {model.version!r}',f'INITIAL = {tuple(int(x) for x in model.initial)!r}',
           '', 'def step(state, symbol):',f'    if len(state) != {model.dimension}: raise ValueError("state width")',
           '    if type(symbol) is not int: raise ValueError("integer symbol required")']
    for a,m in sorted(model.transitions.items()):
        lines.append(f'    if symbol == {a}:')
        lines.extend(lines_for(columns(m),'        '))
    lines += ['    raise ValueError("symbol outside binding")','','def readout(state):']
    lines += lines_for(columns(model.readouts))
    lines += ['', 'def predict(values):',f'    if len(values) > {model.max_length}: raise ValueError("length outside binding")',
              '    state = INITIAL','    for symbol in values:','        state = step(state, symbol)',
              '    return readout(state)','']
    return '\n'.join(lines)
