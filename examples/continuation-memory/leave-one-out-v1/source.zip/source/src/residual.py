"""Exact, bounded multi-output residual-interface learning.

New reference implementation for this return. Mathematical approach: finite
Hankel bases / weighted-automaton learning (Beimel et al.; Worrell's notes).
No implementation copied from those works. No source-family grammar is used.
The tests supplied to `learn` are finite challenges, NOT an equivalence oracle.
Only trusted, inspected offline callables should be supplied as teachers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction as F
from typing import Callable, Iterable, Sequence
import hashlib
import json

Word = tuple[int, ...]
Test = tuple[int, Word]
Vector = tuple[F, ...]
Matrix = tuple[Vector, ...]


@dataclass
class Accounting:
    teacher_calls: int = 0
    teacher_input_symbols: int = 0
    cache_hits: int = 0
    row_reduction_entries: int = 0
    matrix_products: int = 0
    multiply_adds: int = 0
    validation_words: int = 0
    calls_by_teacher: dict[int, int] = field(default_factory=dict)


def dot(x: Sequence[F], y: Sequence[F], meter: Accounting | None = None) -> F:
    if len(x) != len(y):
        raise ValueError('dimension mismatch')
    total = F(0)
    for a, b in zip(x, y):
        if a and b:
            total += a * b
            if meter is not None:
                meter.multiply_adds += 1
    return total


def multiply(a: Matrix, b: Matrix, meter: Accounting | None = None) -> Matrix:
    if not a or not b or len(a[0]) != len(b):
        raise ValueError('invalid matrix dimensions')
    if meter is not None:
        meter.matrix_products += 1
    cols = tuple(zip(*b))
    return tuple(tuple(dot(row, col, meter) for col in cols) for row in a)


def row_times(x: Sequence[F], a: Matrix, meter: Accounting | None = None) -> Vector:
    return multiply((tuple(x),), a, meter)[0]


def identity(n: int) -> Matrix:
    if n < 1:
        raise ValueError('positive dimension required')
    return tuple(tuple(F(int(i == j)) for j in range(n)) for i in range(n))


def inverse(a: Matrix, meter: Accounting | None = None) -> Matrix:
    n = len(a)
    if n == 0 or any(len(row) != n for row in a):
        raise ValueError('square nonempty matrix required')
    rows = [list(map(F, row)) + list(identity(n)[i]) for i, row in enumerate(a)]
    for col in range(n):
        pivot = next((i for i in range(col, n) if rows[i][col]), None)
        if pivot is None:
            raise ValueError('singular matrix')
        rows[col], rows[pivot] = rows[pivot], rows[col]
        q = rows[col][col]
        rows[col] = [x / q for x in rows[col]]
        for i in range(n):
            if i != col and rows[i][col]:
                q = rows[i][col]
                rows[i] = [x - q*y for x, y in zip(rows[i], rows[col])]
                if meter is not None:
                    meter.row_reduction_entries += 2*n
    return tuple(tuple(row[n:]) for row in rows)


class RowBasis:
    """Incremental exact echelon basis, preserving deterministic pivot order."""
    def __init__(self, width: int, meter: Accounting | None = None):
        self.width = width
        self.rows: dict[int, Vector] = {}
        self.meter = meter

    def add(self, values: Sequence[int | F]) -> bool:
        if len(values) != self.width:
            raise ValueError('basis width mismatch')
        row = list(map(F, values))
        for pivot in sorted(self.rows):
            q = row[pivot]
            if q:
                row = [x - q*y for x, y in zip(row, self.rows[pivot])]
                if self.meter is not None:
                    self.meter.row_reduction_entries += self.width
        pivot = next((i for i, value in enumerate(row) if value), None)
        if pivot is None:
            return False
        q = row[pivot]
        self.rows[pivot] = tuple(x/q for x in row)
        return True

    @property
    def pivots(self) -> tuple[int, ...]:
        return tuple(sorted(self.rows))


class Teacher:
    """Memoised complete-program outputs. Cache identity is this teacher object.

    The cache is deliberately not persisted across bindings or code revisions.
    `max_length` bounds BOTH prefixes and their experimental continuations.
    """
    def __init__(self, functions: dict[int, Callable[[Word], int]],
                 alphabet: Sequence[int], max_length: int = 32,
                 meter: Accounting | None = None):
        if not functions or not alphabet or len(set(alphabet)) != len(alphabet):
            raise ValueError('nonempty teachers and unique alphabet required')
        self.functions = functions
        self.alphabet = tuple(alphabet)
        self.max_length = max_length
        self.cache: dict[tuple[int, Word], int] = {}
        self.meter = meter or Accounting()

    def ask(self, task: int, word: Word) -> F:
        if len(word) > self.max_length or any(type(a) is not int or a not in self.alphabet for a in word):
            raise ValueError('query outside binding')
        key = task, word
        if key in self.cache:
            self.meter.cache_hits += 1
            return F(self.cache[key])
        value = self.functions[task](word)
        if type(value) is not int:
            raise ValueError('teacher must return exact integer')
        self.cache[key] = value
        self.meter.teacher_calls += 1
        self.meter.teacher_input_symbols += len(word)
        self.meter.calls_by_teacher[task] = self.meter.calls_by_teacher.get(task, 0) + 1
        return F(value)

    def row(self, prefix: Word, tests: Sequence[Test]) -> Vector:
        return tuple(self.ask(task, prefix + suffix) for task, suffix in tests)


@dataclass(frozen=True)
class Interface:
    alphabet: tuple[int, ...]
    tasks: tuple[int, ...]
    initial: Vector
    transitions: dict[int, Matrix]
    readouts: Matrix
    access: tuple[Word, ...]
    tests: tuple[Test, ...]
    max_length: int = 32

    @property
    def dimension(self) -> int:
        return len(self.initial)

    def state(self, word: Word, meter: Accounting | None = None) -> Vector:
        if len(word) > self.max_length:
            raise ValueError('word exceeds binding')
        state = self.initial
        for a in word:
            if type(a) is not int or a not in self.transitions:
                raise ValueError('symbol outside binding')
            state = row_times(state, self.transitions[a], meter)
        return state

    def predict(self, word: Word, meter: Accounting | None = None) -> Vector:
        return row_times(self.state(word, meter), self.readouts, meter)

    def payload(self) -> dict:
        def number(x: F) -> list[int]:
            return [x.numerator, x.denominator]
        def matrix(a: Matrix) -> list:
            return [[number(x) for x in row] for row in a]
        return {'schema':'zenith_residual_interface_v1', 'alphabet':list(self.alphabet),
                'tasks':list(self.tasks), 'initial':[number(x) for x in self.initial],
                'transitions':{str(k):matrix(v) for k,v in sorted(self.transitions.items())},
                'readouts':matrix(self.readouts), 'access':[list(x) for x in self.access],
                'tests':[[j,list(e)] for j,e in self.tests], 'max_length':self.max_length,
                'status':'finite_challenge_checked_not_universal_certificate'}

    @classmethod
    def from_payload(cls, p: dict) -> Interface:
        if p.get('schema') != 'zenith_residual_interface_v1':
            raise ValueError('unknown schema')
        def matrix(a):
            return tuple(tuple(F(*x) for x in row) for row in a)
        result = cls(tuple(p['alphabet']), tuple(p['tasks']), tuple(F(*x) for x in p['initial']),
                     {int(k):matrix(v) for k,v in p['transitions'].items()}, matrix(p['readouts']),
                     tuple(tuple(x) for x in p['access']),
                     tuple((j,tuple(e)) for j,e in p['tests']), p['max_length'])
        n=result.dimension
        if n<1 or len(result.access)!=n or len(result.tests)!=n or set(result.transitions)!=set(result.alphabet):
            raise ValueError('malformed interface')
        if any(len(m)!=n or any(len(r)!=n for r in m) for m in result.transitions.values()):
            raise ValueError('malformed transition')
        if len(result.readouts)!=n or any(len(r)!=len(result.tasks) for r in result.readouts):
            raise ValueError('malformed readout')
        return result

    @property
    def version(self) -> str:
        return hashlib.sha256(json.dumps(self.payload(),sort_keys=True,separators=(',',':')).encode()).hexdigest()


def learn(teacher: Teacher, challenges: Sequence[Word], *,
          max_dimension: int = 40, max_rounds: int = 20,
          initial_tests: Sequence[Test] | None = None,
          on_candidate: Callable[[int, Interface], None] | None = None) -> tuple[Interface, list[dict]]:
    """Learn a joint interface from final answers, retaining refinement witnesses.

    Current outputs and one-symbol continuations initialise a generic basis.
    Failed closure adds a tested dimension, not a model-written semantic label.
    Challenges must be supplied from development, never the later evaluation.
    """
    tasks = tuple(sorted(teacher.functions))
    tests = list(dict.fromkeys(initial_tests or
                [(j,()) for j in tasks] + [(j,(a,)) for j in tasks for a in teacher.alphabet]))
    for j in tasks:
        if (j,()) not in tests:
            tests.append((j,()))
    history=[]
    for round_no in range(max_rounds):
        # Reachability closure over current tested features; a separate challenge
        # loop is essential because finite closure does not establish correctness.
        basis=RowBasis(len(tests), teacher.meter)
        access=[]
        queue=[()]
        cursor=0
        while cursor<len(queue):
            prefix=queue[cursor];cursor+=1
            row=teacher.row(prefix,tests)
            if basis.add(row):
                access.append(prefix)
                if len(access)>max_dimension:
                    raise RuntimeError('dimension cap exhausted')
                queue.extend(prefix+(a,) for a in teacher.alphabet)
        if not access:
            raise RuntimeError('zero observed series: enlarge development tests rather than assume zero')
        pivots=basis.pivots
        selected_tests=tuple(tests[i] for i in pivots)
        h=tuple(teacher.row(p,selected_tests) for p in access)
        inv=inverse(h,teacher.meter)
        transitions={a:multiply(inv,tuple(teacher.row(p+(a,),selected_tests) for p in access),teacher.meter)
                     for a in teacher.alphabet}
        outputs=tuple(tuple(teacher.ask(j,p) for j in tasks) for p in access)
        readouts=multiply(inv,outputs,teacher.meter)
        model=Interface(teacher.alphabet,tasks,teacher.row((),selected_tests),transitions,readouts,
                        tuple(access),selected_tests,teacher.max_length)
        if on_candidate is not None:
            on_candidate(round_no,model)
        failure=None
        for word in challenges:
            teacher.meter.validation_words+=1
            predicted=model.predict(word,teacher.meter)
            actual=tuple(teacher.ask(j,word) for j in tasks)
            if predicted!=actual:
                failure=(word,predicted,actual);break
        receipt={'round':round_no,'dimension':model.dimension,'candidate_tests':len(tests),
                 'teacher_calls_so_far':teacher.meter.teacher_calls,
                 'access':[list(p) for p in access],
                 'basis_tests':[[j,list(e)] for j,e in selected_tests]}
        if failure is None:
            receipt['status']='passed_finite_development_challenges'
            history.append(receipt)
            return model,history
        word,predicted,actual=failure
        # Locate the first transition that violates an actually measurable feature.
        current=model.initial
        for i,a in enumerate(word):
            current=row_times(current,transitions[a],teacher.meter)
            observed=teacher.row(word[:i+1],selected_tests)
            if current!=observed:
                k=next(k for k,(x,y) in enumerate(zip(current,observed)) if x!=y)
                task,suffix=selected_tests[k]
                new_test=(task,(a,)+suffix)
                if new_test in tests:
                    raise RuntimeError('refinement failed to add a distinction')
                tests.append(new_test)
                receipt.update(status='refined',counterexample=list(word),
                    predicted=[str(x) for x in predicted],observed=[str(x) for x in actual],
                    failing_prefix=list(word[:i]),new_test=[task,list(new_test[1])],
                    predicted_feature=str(current[k]),observed_feature=str(observed[k]))
                history.append(receipt)
                break
        else:
            # If state features match but readout does not, add the violating
            # output's empty suffix (normally already present); do not hide it.
            raise RuntimeError('readout inconsistency: finite closure implementation error')
    raise RuntimeError('refinement cap exhausted')
