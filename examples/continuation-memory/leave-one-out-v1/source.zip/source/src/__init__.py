"""Offline research reference; not a production executor."""
