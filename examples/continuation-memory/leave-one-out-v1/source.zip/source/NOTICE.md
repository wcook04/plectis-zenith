# Attribution and research notice

The six source fixtures under `archive/programme_*.py` are exact extractions from the supplied Zenith repository snapshot, commit `b6d1b9e23eb4a743a85729cb6715641d7cdb8ad9`. Their original paths, JSON pointers and SHA256 hashes are in `archive/programmes.json`. The source repository's Apache License 2.0 is preserved in `LICENSE` and `archive/LICENSE-APACHE-2.0.txt`; its research boundary is preserved in `archive/RESEARCH_NOTICE.md`.

The learner, evaluator, runtime, experiments, tests and explanatory text in this return were newly constructed for this research handoff. New prototype code is supplied under Apache License 2.0. No source implementation from the cited papers was copied. Mathematical antecedents are credited in `sources/LITERATURE.md` and `DERIVATION.md`.

This is a private research return, not publication of the original packet or a production certification. No credentials, account data, complete historical archives, third-party paper copies or unrelated repository material are included. Proposed live integration remains Type A's responsibility.
