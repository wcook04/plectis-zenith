#!/usr/bin/env python3
"""Reproduce the developmental acquisition/reuse study offline.

Only standard-library dependencies. No model calls or network. The later
consumer is instantiated after the first interface has been serialised. This
is executable information-flow ordering, not independent preregistration.
"""
from __future__ import annotations
import argparse
from dataclasses import asdict
from fractions import Fraction as F
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import random
import time

from src.host import load_programmes
from src.residual import Accounting,Interface,Teacher,Word,learn,inverse,multiply,row_times
from src.runtime import Runtime,RuntimeCost,State,apply,columns,compile_inline
from evaluation.reference import OrdinaryReference,certificate,oracle
from evaluation.controls import fit_disclosed_family,ordinary_alternatives,ordinary_forward

ROOT=Path(__file__).resolve().parent
ALPHABET=tuple(range(-8,9))


def dump(path:Path,obj)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')


def hash_object(obj)->str:
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def development()->list[Word]:
    r=random.Random(6701)
    words=[w for n in range(4) for w in itertools.product((-2,-1,0,1,2),repeat=n)]
    words += [tuple(r.choice(ALPHABET) for unused in range(r.randint(4,12))) for i in range(40)]
    return words


def later_words()->list[Word]:
    r=random.Random(99073)
    words=[w for n in range(7) for w in itertools.product((-2,0,2),repeat=n)]
    words += [tuple(r.choice(ALPHABET) for unused in range(r.randint(1,32))) for i in range(256)]
    return words


def consumer_jobs()->list[dict]:
    r=random.Random(80261014);jobs=[]
    for k in range(64):
        p=tuple(r.choice(ALPHABET) for unused in range(r.randint(6,12)))
        s=tuple(r.choice(ALPHABET) for unused in range(r.randint(3,7)))
        mids=[]
        for j in range(8):
            while True:
                middle=tuple(r.choice(ALPHABET) for unused in range(r.randint(0,5)))
                if middle not in mids:break
            mids.append(middle)
        weights=tuple(r.randint(-3,3) for unused in range(5))
        jobs.append({'id':k,'prefix':p,'suffix':s,'alternatives':tuple(mids),'weights':weights})
    return jobs


def truth(configs,ids,word):
    return tuple(oracle(configs[j],word) for j in ids)


def collision(function)->dict:
    """Find a concrete equal-current-answer / unequal-continuation witness."""
    seen={};evaluations=0
    for n in range(5):
        for word in itertools.product((-2,-1,0,1,2),repeat=n):
            present=function(word);evaluations+=1
            for old in seen.get(present,[]):
                for suffix in ((0,),(1,),(-1,),(0,0)):
                    left=function(old+suffix);right=function(word+suffix);evaluations+=2
                    if left!=right:
                        return {'left':old,'right':word,'same_current_value':present,'continuation':suffix,
                                'left_future':left,'right_future':right,'teacher_evaluations':evaluations}
            seen.setdefault(present,[]).append(word)
    raise RuntimeError('no finite witness found')


def timed(function):
    before=time.perf_counter();value=function()
    return value,time.perf_counter()-before


def main(out:Path)->None:
    out=out.resolve()
    if out==ROOT or ROOT in out.parents:
        raise ValueError('output must be outside the source package')
    if out.exists() and any(out.iterdir()):
        raise ValueError('output must be absent or empty')
    out.mkdir(parents=True,exist_ok=True)
    fs=load_programmes(ROOT)
    configs={x['id']:x['config'] for x in json.loads((ROOT/'evaluation/oracle_configs.json').read_text())}
    calibration=json.loads((ROOT/'archive/calibration.json').read_text())
    ids=tuple(range(5));words=development();timings={};observed_caches=[]
    def collect(prefix):
        return lambda i,m:dump(out/'candidates'/f'{prefix}_{i}.json',m.payload())

    t=Teacher({j:fs[j] for j in ids},ALPHABET)
    (initial,trajectory),timings['initial_extraction_seconds']=timed(lambda:learn(t,words,on_candidate=collect('initial')))
    dump(out/'library_v1.json',initial.payload());dump(out/'initial_trajectory.json',trajectory)
    frozen={'interface_version':initial.version,'payload_sha256':hashlib.sha256((out/'library_v1.json').read_bytes()).hexdigest(),
            'tasks_used':ids,'later_programme_not_used':5,'development_words_sha256':hash_object(words),
            'source_hashes':{r['id']:r['source_sha256'] for r in json.loads((ROOT/'archive/programmes.json').read_text()) if r['id'] in ids},
            'ordering':'serialised before later_words, consumer_jobs or programme-5 fitting',
            'status':'developmental ordering, not independent preregistration'}
    dump(out/'frozen_receipt.json',frozen)
    initial=Interface.from_payload(json.loads((out/'library_v1.json').read_text()))
    runtime=Runtime(initial)
    proof=certificate(initial,OrdinaryReference({j:configs[j] for j in ids}))
    if not proof['passed']:raise RuntimeError('exact reference certificate failed')
    dump(out/'certificate_v1.json',proof)
    initial_cost=asdict(t.meter)
    observed_caches.append(('initial',dict(t.cache)))
    print('initial:',initial.dimension,'coordinates,',t.meter.teacher_calls,'teacher executions',flush=True)

    # A catalogue-aware serious control fits only public calibration, not private settings.
    (fitted,fitter_cost),timings['family_control_fit_seconds']=timed(lambda:fit_disclosed_family(calibration,tuple(range(6))))
    if fitted!=configs:raise RuntimeError('blind public-family fit differs from evaluator')
    ordinary=OrdinaryReference({j:fitted[j] for j in ids})
    dump(out/'ordinary_family_control.json',{'fitted':fitted,'cost':fitter_cost})

    # Instantiate later work only after v1 is frozen. No later output selects it.
    tests=later_words();eval_cost=RuntimeCost();correct=inline_correct=original_correct=0
    inline_source=compile_inline(initial);(out/'compiled_inline.py').write_text(inline_source)
    ns={};exec(compile(inline_source,'generated_inline','exec'),ns)
    observed=[]
    for word in tests:
        expected=truth(configs,ids,word);answer=runtime.predict(word,eval_cost)
        flat=ns['predict'](word);original=tuple(fs[j](word) for j in ids)
        correct+=sum(a==b for a,b in zip(answer,expected))
        inline_correct+=sum(a==b for a,b in zip(flat,expected))
        original_correct+=sum(a==b for a,b in zip(original,expected))
        observed.append([word,list(answer),list(expected)])
    dump(out/'later_validation.json',{'words':len(tests),'outputs':len(tests)*len(ids),'learned_correct':correct,
        'inline_correct':inline_correct,'archived_programme_correct':original_correct,
        'rows_sha256':hash_object(observed),'runtime_cost':asdict(eval_cost),
        'panel':'all words of length <=6 over {-2,0,2}, plus 256 seeded words over -8..8 of length <=32',
        'status':'developer-authored later-use validation; not statistical confirmation'})
    with gzip.GzipFile(filename=str(out/'later_rows.json.gz'),mode='wb',mtime=0) as g:
        g.write(json.dumps(observed,separators=(',',':')).encode())

    # Every prefix and a fork: stored operating state receives one new value only.
    r=random.Random(44319);prefix_outputs=prefix_correct=fork_outputs=fork_correct=0
    for repeat in range(64):
        word=tuple(r.choice(ALPHABET) for unused in range(32));state=runtime.initial()
        for k in range(33):
            if k:state=runtime.step(state,word[k-1])
            expected=truth(configs,ids,word[:k]);got=runtime.read(state)
            prefix_outputs+=len(ids);prefix_correct+=sum(a==b for a,b in zip(got,expected))
            if k<32:
                a=r.choice(ALPHABET);fork=runtime.step(state,a)
                exp=truth(configs,ids,word[:k]+(a,));got=runtime.read(fork)
                fork_outputs+=len(ids);fork_correct+=sum(a==b for a,b in zip(got,exp))
    dump(out/'prefix_and_fork.json',{'prefix_outputs':prefix_outputs,'prefix_correct':prefix_correct,
                                    'fork_outputs':fork_outputs,'fork_correct':fork_correct,'trajectories':64})

    jobs=consumer_jobs();consumer_cost=RuntimeCost();case_rows=[]
    totals={a:{'correct':0,'outputs':0,'decisions_correct':0,'decisions':0} for a in
            ('learned_two_sided','ordinary_forward','ordinary_two_sided','whole_programmes','reset_addition','neutralise_prefix')}
    source_executions=source_symbols=0
    for job in jobs:
        p,mids,s=job['prefix'],job['alternatives'],job['suffix']
        expected=[truth(configs,ids,p+middle+s) for middle in mids]
        candidate_answers={
            'learned_two_sided':runtime.alternatives(p,mids,s,consumer_cost),
            'ordinary_forward':ordinary_forward(ordinary,p,mids,s),
            'ordinary_two_sided':ordinary_alternatives(ordinary,p,mids,s),
            'whole_programmes':[tuple(fs[j](p+middle+s) for j in ids) for middle in mids],
            'reset_addition':[tuple(fs[j](p)+fs[j](middle)+fs[j](s) for j in ids) for middle in mids],
            'neutralise_prefix':runtime.alternatives((),mids,s)}
        source_executions+=len(ids)*len(mids);source_symbols+=len(ids)*sum(len(p)+len(m)+len(s) for m in mids)
        def choice(rows):
            return min(range(len(rows)),key=lambda k:(sum(a*b for a,b in zip(rows[k],job['weights'])),k))
        target_choice=choice(expected)
        for arm,answers in candidate_answers.items():
            totals[arm]['outputs']+=len(ids)*len(mids)
            totals[arm]['correct']+=sum(a==b for left,right in zip(answers,expected) for a,b in zip(left,right))
            totals[arm]['decisions']+=1;totals[arm]['decisions_correct']+=int(choice(answers)==target_choice)
        case_rows.append({**job,'expected':expected,'selected':target_choice,'answers':candidate_answers})
    dump(out/'consumer.json',{'workloads':len(jobs),'candidate_sequences':sum(len(j['alternatives']) for j in jobs),
        'arms':totals,'learned_runtime_cost':asdict(consumer_cost),
        'whole_programme_calls':source_executions,'whole_programme_input_symbols':source_symbols,
        'suffix_projection_arithmetic_excluded_from_runtime_counter':True,
        'note':'weighted-term counts are not complete CPU accounting; measured wall times are separate. Reset/neutralise arms are diagnostic, not serious competitors.'})
    with gzip.GzipFile(filename=str(out/'consumer_rows.json.gz'),mode='wb',mtime=0) as g:
        g.write(json.dumps(case_rows,separators=(',',':')).encode())

    # Composition of transformations, contrasted with composition of reset values.
    composition_cost=Accounting();composition_correct=composition_outputs=0
    for job in jobs[:16]:
        p,mids,s=job['prefix'],job['alternatives'],job['suffix']
        for middle in mids[:2]:
            left=runtime.summary(p,composition_cost);centre=runtime.summary(middle,composition_cost);right=runtime.summary(s,composition_cost)
            joint=runtime.compose(runtime.compose(left,centre,composition_cost),right,composition_cost)
            answer=runtime.read(runtime.apply_summary(runtime.initial(),joint))
            expected=truth(configs,ids,p+middle+s)
            composition_outputs+=len(ids);composition_correct+=sum(a==b for a,b in zip(answer,expected))
    witness=collision(fs[1])
    dump(out/'composition.json',{'outputs':composition_outputs,'correct':composition_correct,
         'full_transform_algebra_cost':asdict(composition_cost),'scalar_cut_witness':witness,
         'warning':'full d-by-d chunk summaries can cost more than recomputation on these short lists'})

    # A later acquired programme is first attempted as a readout of the frozen interface.
    late=Teacher({5:fs[5]},ALPHABET)
    h=tuple(t.row(p,initial.tests) for p in initial.access)
    beta=multiply(inverse(h),tuple((late.ask(5,p),) for p in initial.access))
    late_failure=None;fit_checks=0
    for word in words:
        predicted=row_times(tuple(map(F,runtime.run(word).values)),beta)[0];actual=late.ask(5,word);fit_checks+=1
        if predicted!=actual:
            late_failure={'word':word,'predicted':str(predicted),'observed':str(actual)};break
    if late_failure is None:raise RuntimeError('expected readout-only insufficiency not witnessed')
    dump(out/'failed_new_readout.json',{'basis_examples':len(initial.access),'challenge_checks':fit_checks,
         'teacher_cost':asdict(late.meter),'failure':late_failure,'beta':[[str(x) for x in row] for row in beta],
         'scope':'refutes this linear readout of v1; not a general impossibility theorem for arbitrary nonlinear consumers'})
    observed_caches.append(('late_failed_fit',dict(late.cache)))

    warm=Teacher(fs,ALPHABET);warm.cache.update(t.cache);warm.cache.update(late.cache)
    new_tests=list(initial.tests)+[(5,())]+[(5,(a,)) for a in ALPHABET]
    (grown,growth),timings['warm_extension_seconds']=timed(lambda:learn(warm,words,initial_tests=new_tests,on_candidate=collect('grown')))
    observed_caches.append(('warm_extension',dict(warm.cache)))
    dump(out/'library_v2.json',grown.payload());dump(out/'growth_trajectory.json',growth)
    growth_proof=certificate(grown,OrdinaryReference(fitted))
    if not growth_proof['passed']:raise RuntimeError('grown reference certificate failed')
    dump(out/'certificate_v2.json',growth_proof)
    print('extension:',grown.dimension,'coordinates,',warm.meter.teacher_calls,'new teacher executions',flush=True)

    fresh=Teacher(fs,ALPHABET)
    (fresh_model,fresh_history),timings['fresh_joint_extraction_seconds']=timed(lambda:learn(fresh,words))
    observed_caches.append(('fresh_joint',dict(fresh.cache)))
    fresh_proof=certificate(fresh_model,OrdinaryReference(fitted))
    if not fresh_proof['passed']:raise RuntimeError('fresh control failed')
    rt2=Runtime(grown);growth_correct=growth_outputs=0
    # Reuse deterministic later words; analyse separately, never pool with v1.
    for word in tests[-128:]:
        expected=truth(configs,tuple(range(6)),word);got=rt2.predict(word)
        growth_outputs+=6;growth_correct+=sum(a==b for a,b in zip(got,expected))
    mismatch_rejected=False
    try:rt2.step(runtime.initial(),1)
    except ValueError:mismatch_rejected=True
    dump(out/'extension.json',{'old_dimension':initial.dimension,'new_dimension':grown.dimension,
        'new_reference_dimension':growth_proof['reference_dimension'],
        'old_extraction_cost':initial_cost,'failed_readout_cost':asdict(late.meter),
        'warm_incremental_cost':asdict(warm.meter),'fresh_six_programme_cost':asdict(fresh.meter),
        'warm_round_dimensions':[r['dimension'] for r in growth],
        'fresh_round_dimensions':[r['dimension'] for r in fresh_history],
        'later_outputs':growth_outputs,'later_correct':growth_correct,'old_version_rejected':mismatch_rejected,
        'note':'Warm extension has prior stored evidence and incurs its original cost. A smaller incremental bill is not automatically smaller lifetime cost.'})

    # Independent per-programme extraction: ordinary module reuse is fully permitted.
    separate=[]
    for task in ids:
        isolated=Teacher({task:fs[task]},ALPHABET)
        (model,trace),seconds=timed(lambda:learn(isolated,words))
        separate.append({'task':task,'dimension':model.dimension,'cost':asdict(isolated.meter),
                         'reference_certificate_passed':certificate(model,OrdinaryReference({task:fitted[task]}))['passed']})
        timings[f'separate_{task}_seconds']=seconds
        observed_caches.append((f'separate_{task}',dict(isolated.cache)))
    dump(out/'separate_control.json',{'modules':separate,'total_coordinates':sum(x['dimension'] for x in separate),
          'teacher_executions':sum(x['cost']['teacher_calls'] for x in separate),
          'ordinary_unshared_registers':ordinary.dimension,
          'ordinary_reachable_linear_dimension':proof['reachable_reference_dimension'],
          'warning':'coordinate counts are not bit-memory, code-size or latency claims'})

    # An external semantic change can evade every retained short probe.
    changed=(8,)*31
    stable=fs[0](changed);drifted=stable+1
    max_extraction_query=max(len(w) for j,w in t.cache)
    dump(out/'scope_counterexample.json',{'authored_changed_source':'programme 0 plus 1 only when input equals [8]*31',
        'retained_extraction_query_max_length':max_extraction_query,'all_acquisition_queries_unchanged':changed not in {w for j,w in t.cache if j==0},
        'independent_legal_challenge':changed,'old_prediction':runtime.predict(changed)[0],'changed_truth':drifted,
        'caught':runtime.predict(changed)[0]!=drifted,
        'scope':'outside the disclosed polynomial family; an old algebraic certificate does not certify unchanged external source semantics'})

    # Retrieving actual persisted versions: byte and hash accounting, not free memory.
    retrieval=[]
    for name in ('library_v1.json','library_v2.json'):
        data=(out/name).read_bytes();loaded=Interface.from_payload(json.loads(data))
        retrieval.append({'file':name,'bytes_read':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                          'interface_version':loaded.version,'parse_count':1,'validated_dimensions':loaded.dimension})
    dump(out/'retrieval.json',{'loads':retrieval,'wrong_version_rejected':mismatch_rejected,
        'semantic_warning':'Byte identity is custody, not a drift detector.'})

    # Whole-run latency diagnostics, including suffix-index construction in each call.
    # Ordinary forward refactoring is allowed to win. No ratio is a new scientific claim.
    benchmark_jobs=jobs[:16]
    funcs={
        'learned_two_sided':lambda: [runtime.alternatives(j['prefix'],j['alternatives'],j['suffix']) for j in benchmark_jobs],
        'ordinary_forward':lambda: [ordinary_forward(ordinary,j['prefix'],j['alternatives'],j['suffix']) for j in benchmark_jobs],
        'ordinary_two_sided':lambda: [ordinary_alternatives(ordinary,j['prefix'],j['alternatives'],j['suffix']) for j in benchmark_jobs],
        'archived_recompute':lambda: [[tuple(fs[t](j['prefix']+m+j['suffix']) for t in ids) for m in j['alternatives']] for j in benchmark_jobs],
        'compiled_inline_recompute':lambda: [[ns['predict'](j['prefix']+m+j['suffix']) for m in j['alternatives']] for j in benchmark_jobs]}
    bench={}
    for name,fn in funcs.items():
        output=fn();runs=[]
        for repeat in range(5):
            same,elapsed=timed(fn)
            if same!=output:raise RuntimeError('nondeterministic benchmark')
            runs.append(elapsed)
        bench[name]={'seconds':runs,'median_seconds':sorted(runs)[len(runs)//2],
                     'outputs_per_run':16*8*5,'output_sha256':hash_object(output)}
    timings['later_consumer_benchmark']=bench
    dump(out/'timings.json',timings)

    # Compact complete teacher-query union, with arm membership, no duplicate raw dumps.
    union={};memberships={}
    for arm,cache in observed_caches:
        for key,value in cache.items():
            if key in union and union[key]!=value:raise RuntimeError('teacher changed across arms')
            union[key]=value;memberships.setdefault(key,[]).append(arm)
    with gzip.GzipFile(filename=str(out/'teacher_queries.jsonl.gz'),mode='wb',mtime=0) as g:
        for (task,word),value in sorted(union.items()):
            g.write((json.dumps({'task':task,'input':word,'value':value,'arms':memberships[task,word]},separators=(',',':'))+'\n').encode())

    summary={'status':'developmental_mechanism_and_exact_reference_certificate',
        'model_calls':0,'paid_inference_usd':0,'initial_programmes':ids,
        'initial_round_dimensions':[x['dimension'] for x in trajectory],
        'initial_teacher_executions':initial_cost['teacher_calls'],'initial_dimension':initial.dimension,
        'separate_coordinate_count':sum(x['dimension'] for x in separate),
        'ordinary_reference_registers':ordinary.dimension,'ordinary_minimal_linear_dimension':proof['reachable_reference_dimension'],
        'initial_certificate_passed':proof['passed'],'later_validation_correct':correct,'later_validation_outputs':len(tests)*5,
        'prefix_correct':prefix_correct,'prefix_outputs':prefix_outputs,'fork_correct':fork_correct,'fork_outputs':fork_outputs,
        'consumer_arms':totals,'compound_outputs':composition_outputs,'compound_correct':composition_correct,
        'grown_dimension':grown.dimension,'grown_certificate_passed':growth_proof['passed'],
        'failed_new_readout':late_failure,'teacher_query_union':len(union),
        'unpriced':'human research, local CPU and storage; wall-time diagnostics reported separately',
        'not_established':['new state-learning theory','special graph benefit','latency advantage over competent ordinary code',
                           'autonomous LLM acquisition or learned update-policy improvement in the executed experiment','independent confirmation','recursive self-improvement']}
    dump(out/'summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    main(args.out)
