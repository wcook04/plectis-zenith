# Derivation: interfaces defined by observable continuations

This is a worked mathematical account of the implemented construction, not a novelty claim. The finite-rank learning idea is classical weighted-automaton learning; see [1,2] in `sources/LITERATURE.md`. The implementation is newly written. The proofs below spell out the concrete multi-output interface and reference certificate used in this return.

## 1. What a boundary may safely forget

Let `Σ` be an input alphabet, `h` a history and `P_j: Σ* → Q` a deterministic programme. Fix a family of future questions `D`, comprising programme indices and continuations. Define

`h ~_D h'  iff  P_j(he) = P_j(h'e) for every (j,e) in D`.

A state abstraction `φ(h)` is sufficient for these questions when equal abstract states imply `~_D`. It need not preserve anything the declared consumers cannot observe. Enlarging `D` can split an old equivalence class. A reusable abstraction is therefore relative to its future obligations, not an unconditional semantic object.

**Scalar-boundary obstruction.** Suppose `φ(h)=φ(h')` but one permitted continuation `e` yields different required answers. A deterministic downstream function of only `φ(h)` and `e` receives the same arguments in both cases, so it returns the same value. It must be wrong in at least one case. This statement does not assume a particular model or implementation. It explains the actual `8 → {32,−16}` witness.

For a state that updates one input at a time, the relevant equivalence must also respect concatenation: equal states must remain observationally equivalent after any allowed next symbol. A collection of features that fits current answers but cannot be consistently updated is not yet an operational interface.

## 2. An observable linear realisation

Choose tests `E = ((j_1,e_1), …, (j_d,e_d))` and set

`φ(h) = (P_j1(he_1), …, P_jd(he_d))`.

Choose access histories `A = (a_1, …, a_d)` so the square matrix

`H[i,k] = P_jk(a_i e_k)`

is invertible over the rationals. For each input symbol `x`, form

`H_x[i,k] = P_jk(a_i x e_k)`.

Also form `Y[i,j] = P_j(a_i)`. Solve

`M_x = H^(-1) H_x`,   `B = H^(-1) Y`,   `α = φ(empty)`.

The candidate predicts `α M_h B`, where `M_h` is the ordered product of symbol transitions. The construction is exact on the basis rows. That alone does not prove it correct on every history: the observed tests may miss an independent future distinction.

The implementation grows access rows by exact rank tests and explores their one-symbol extensions. It then performs a distinct development-challenge pass. This second step is essential: finite row closure on a deficient set of questions is not an equivalence oracle. The learner reports finite-challenge success, never unconditional truth.

## 3. Why a failing continuation can add a coordinate

Consider a tested word on which the candidate is wrong. Compare predicted and actual feature vectors along its prefixes. The initial feature vector is directly measured. At the first mismatch there is a prefix `h`, symbol `x` and old test `(j,e)` such that the vector at `h` was correct but its update predicts

`φ(h) M_x[:,k] != P_j(hxe)`.

Add the test `(j, xe)`. If its column were already the same linear combination of old columns on every history, the measured values on the invertible basis would fix that combination uniquely. Those same basis values define `M_x[:,k]`, which would then predict the new test correctly at `h`—a contradiction. Thus this witnessed failure establishes a new independent test direction for the deterministic series under consideration.

This reasoning explains why the trajectory can carry both a structural edit and its justification. It does not depend on a natural-language name for the missing distinction. The learner records the failing word, earlier prefix, old feature, numerical discrepancy and added test. Resources remain bounded: too many coordinates, too many rounds, out-of-scope queries or an unresolved zero initial series terminate rather than manufacture a certificate.

## 4. Why the current source family admits a linear state

This fact is used by the evaluator and to interpret the result, not passed to the learner. For a fixed input symbol `x`, a source's pointwise contribution has form

`a*x + b*x² + c*x³ + γ*x*m`,

where `m` is absent, the previous input, or the sum of previous inputs. Maintain a constant coordinate equal to one, the required memory, and the running value for each cumulative-sum pass. Updating these registers is linear in the old register vector once `x` is fixed; the polynomial's value multiplies the constant coordinate. Adjacent memory becomes `x`; prefix memory increases by `x`.

Repeated cumulative summation updates successive registers using newly updated earlier registers. An independently organised final-answer formula weights the contribution at position `i` by

`binomial(n - i + r - 2, r - 1)`

for zero-based position `i`, length `n`, and `r` cumulative passes. `evaluation/reference.py` implements both formulations. The archive's six configurations are extracted unchanged into evaluator-only data.

The resulting finite-rank structure is therefore unsurprising to the researcher. The acquisition test is whether the learner recovers an interface from final executions rather than being supplied those registers. Success is not discovery of an unknown mathematical law.

## 5. The exact reference certificate

Write the independently organised reference state as a row vector `r(h)`, with initial vector `r0`, transitions `R_x` and output matrix `B_ref`. Each learned test is a reference suffix followed by a particular readout. Hence a matrix `C` can be constructed directly from the declared tests so that

`φ(h) = r(h) C`

whenever the reference is the true teacher.

The checker independently obtains a basis `U` of the reference's reachable row space: start with `r0`, append `u R_x` for independent discovered rows, and stop when no new independent direction is found. It checks

`r0 C = α`,

`U R_x C = U C M_x` for every symbol `x`,

`U B_ref = U C B`.

**Sufficiency.** Every reachable state lies in the span of `U`. The transition identity therefore holds at that state. Induction on word length gives `r(h) C = α M_h`. The readout identity then gives `r(h) B_ref = α M_h B` for all finite words over the alphabet.

It is important to check the reachable space rather than require equality on every arbitrary assignment to the reference's stored registers. Two separately stored copies of the previous input agree on every reachable state; impossible states that set them differently are irrelevant. An early development check incorrectly demanded equality on that larger space. It was corrected before the reported experiment; the development note records this rather than counting it as a scientific failure.

**What is and is not certified.** These are exact equalities over rationals, checked by tested ordinary code. They establish agreement with a fixed formal reference. They do not establish that a changing physical process or software service has those semantics, or that the observations used to fit a reference are independently complete. A code hash binds bytes; a version identifies a representation; neither implies semantic stationarity. The API's length-32 restriction is still enforced despite the formal reference induction extending further.

## 6. The precise minimality statement

The observed square `H` has rank `d`. Any linear realisation with `k` coordinates factors its corresponding observation matrix through a `k`-dimensional state, so `rank(H) ≤ k`. A verified `d`-coordinate realisation therefore attains the minimum rational linear dimension for the series it represents.

For the first five outputs this is 14. The separately stored reference has 16 registers and reachable dimension 14; independent learned modules have 20 total coordinates. After the sixth output arrives the joint dimension is 16.

This does **not** prove the smallest number of arbitrary Python values, bits, source lines or inference tokens. An unrestricted integer could encode an entire bounded history. A short symbolic recurrence could be far cheaper than a dense matrix. Coordinate minimality is one algebraic property, not the retention objective.

Nor is the latent meaning of every implementation unique. For invertible `T`, replacing `φ` by `φT`, transitions by `T^(-1) M_x T`, and readouts by `T^(-1)B` preserves predictions. Observable tests give the exported coordinates operational definitions; an equivalent internal implementation can still use different coordinates. Current observational agreement also does not warrant discarding distinct programmes whose later applicability may differ.

## 7. Composition and backward requirements

For a chunk `c = x_1 … x_n`, let `M_c = M_x1 … M_xn`. Associativity gives `M_(pq) = M_p M_q`. A chunk is reusable on arbitrary reachable incoming state precisely because it represents the transformation, not just its reset answer `α M_c B`.

For a fixed suffix `s`, define `Q_s = M_s B`. All alternatives `m` after a shared prefix `p` have answers

`φ(p) M_m Q_s`.

`Q_s` can be computed backwards through the suffix: begin at the required readouts and repeatedly left-multiply by the preceding symbol transition. This is a concrete consumer requirement, not a metaphysical purpose field. Its numerical entries need not have independently meaningful world interpretations; its whole role is established by the composition identity.

Full `d×d` chunk summaries can have cubic matrix-composition cost in a naïve implementation. A `d×number_of_outputs` suffix projection can be cheaper, while an ordinary forward loop can be cheaper still. The package retains all three comparisons. An abstraction can be valuable as a discovered interface while the matrix representation loses as a deployment format.

## 8. What extension failure establishes

The sixth programme's attempted linear readout has a unique solution on the old invertible basis. A new observed disagreement refutes that linear readout. Because every linear readout agreeing on the basis has the same coefficients, no other linear readout of those coordinates fits both the basis and the counterexample. Enlarging the observation basis succeeds.

An arbitrary nonlinear readout is a different hypothesis class. The failure does not rule it out; doing so would require, for example, two histories with exactly the same complete old state and different sixth-programme answers. The package does not assert such a witness. Its rigorous scalar-boundary witness is a separate, weaker-interface claim.

The operative lesson is therefore bounded: retain the experiment that defeated a proposed composition, and use its actual mathematical scope when deciding whether to enlarge state, change the consumer or abandon that composition.
