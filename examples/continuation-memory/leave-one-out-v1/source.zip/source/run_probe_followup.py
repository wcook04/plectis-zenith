#!/usr/bin/env python3
"""Exploratory, post-main-run control: sparse initial continuation probes.

The hypothesis was selected after inspecting the first experiment's costs.
Every tried seed/extension variant is retained; no independent confirmation is
claimed. Exact certificates check each fitted model against the same reference.
"""
from __future__ import annotations
import argparse
from dataclasses import asdict
from fractions import Fraction as F
import gzip
import hashlib
import json
from pathlib import Path
import time
from run_experiment import ALPHABET, ROOT, development, later_words, dump, hash_object
from src.host import load_programmes
from src.residual import Teacher, learn, inverse, multiply, row_times
from src.runtime import Runtime
from evaluation.reference import OrdinaryReference, certificate, oracle


def run(out:Path)->None:
    out=out.resolve()
    if out==ROOT or ROOT in out.parents or (out.exists() and any(out.iterdir())):
        raise ValueError('output must be empty/absent and outside source package')
    out.mkdir(parents=True,exist_ok=True)
    fs=load_programmes(ROOT)
    configs={x['id']:x['config'] for x in json.loads((ROOT/'evaluation/oracle_configs.json').read_text())}
    words=development(); records={};caches={};times={};objects={}
    def acquire(name, tasks, seeds, reuse=None):
        t=Teacher({j:fs[j] for j in tasks},ALPHABET)
        if reuse is not None:t.cache.update(reuse)
        start=time.perf_counter();model,trace=learn(t,words,initial_tests=seeds)
        times[name]=time.perf_counter()-start
        proof=certificate(model,OrdinaryReference({j:configs[j] for j in tasks}))
        if not proof['passed']:raise AssertionError(name+' certificate failed')
        row={'tasks':list(tasks),'initial_tests':seeds,'dimension':model.dimension,
             'trajectory':trace,'cost':asdict(t.meter),'certificate':proof,
             'version':model.version,'prior_cache_rows':len(reuse or {}),
             'final_cache_rows':len(t.cache)}
        dump(out/f'{name}.json',row)
        records[name]=row;caches[name]=dict(t.cache);objects[name]=model
        return t,model
    anchor=ALPHABET[0]
    t,v1=acquire('single_anchor',range(5),[(j,()) for j in range(5)]+[(0,(anchor,))])
    dump(out/'library_v1.json',v1.payload())
    acquire('single_suffix_each',range(5),[(j,()) for j in range(5)]+[(j,(anchor,)) for j in range(5)])

    # Attempt ordinary readout reuse before any structure expansion, charge it.
    late=Teacher({5:fs[5]},ALPHABET)
    h=tuple(t.row(p,v1.tests) for p in v1.access)
    beta=multiply(inverse(h),tuple((late.ask(5,p),) for p in v1.access))
    failure=None;checks=0
    for w in words:
        guess=row_times(v1.state(w),beta)[0];actual=late.ask(5,w);checks+=1
        if guess!=actual:
            failure={'word':w,'predicted':str(guess),'observed':str(actual)};break
    if failure is None:raise AssertionError('linear readout unexpectedly suffices')
    dump(out/'failed_readout.json',{'cost':asdict(late.meter),'checks':checks,'failure':failure,
        'scope':'failure of a linear readout, not of every possible nonlinear consumer'})
    caches['failed_readout']=dict(late.cache)
    merged=dict(t.cache);merged.update(late.cache)
    old_seeds=list(v1.tests)+[(5,())]
    warm,v2=acquire('warm_after_failed_readout',range(6),old_seeds+[(5,(anchor,))],merged)
    acquire('warm_no_new_anchor_after_failure',range(6),old_seeds,merged)
    # No failed attempt: comparison from the preliminary follow-up, retained.
    acquire('warm_direct',range(6),old_seeds+[(5,(anchor,))],t.cache)
    fresh_seeds=[(j,()) for j in range(6)]+[(0,(anchor,))]
    acquire('retained_measurements_only',range(6),fresh_seeds,t.cache)
    acquire('retained_tests_only',range(6),old_seeds+[(5,(anchor,))])
    fresh,vfresh=acquire('fresh_six',range(6),fresh_seeds)
    dump(out/'library_v2.json',v2.payload())

    # Ordinary separately learnt modules also get the sparse-seed improvement.
    separate=[]
    for j in range(5):
        tt,mm=acquire(f'separate_{j}',(j,),[(j,()),(j,(anchor,))])
        separate.append({'task':j,'dimension':mm.dimension,'calls':tt.meter.teacher_calls})

    # Read-only later-use validation; never fed back into any fit.
    later=later_words()[-128:];validation={}
    for name in ('single_anchor','single_suffix_each','warm_after_failed_readout','fresh_six'):
        m=objects[name];rt=Runtime(m);correct=0
        for w in later:
            correct+=sum(a==oracle(configs[j],w) for j,a in zip(m.tasks,rt.predict(w)))
        validation[name]={'correct':correct,'outputs':len(later)*len(m.tasks)}
        if correct!=validation[name]['outputs']:raise AssertionError(name+' later check failed')
    dump(out/'later_validation.json',validation)

    a=records['single_anchor']['cost']['teacher_calls'];f=late.meter.teacher_calls
    w=warm.meter.teacher_calls;d=records['warm_direct']['cost']['teacher_calls']
    fresh_calls=fresh.meter.teacher_calls
    summary={'status':'exploratory_post_main_run_cost_control','model_calls':0,
        'initial_calls':a,'initial_dimension':v1.dimension,
        'initial_dimensions':[r['dimension'] for r in records['single_anchor']['trajectory']],
        'failed_readout_calls':f,'warm_incremental_calls_after_failure':w,
        'warm_lifetime_calls_including_failure':a+f+w,'warm_direct_incremental_calls':d,
        'warm_direct_lifetime_calls':a+d,'fresh_six_calls':fresh_calls,
        'warm_lifetime_minus_fresh_calls':a+f+w-fresh_calls,
        'retained_measurements_only_incremental_calls':records['retained_measurements_only']['cost']['teacher_calls'],
        'retained_tests_only_incremental_calls':records['retained_tests_only']['cost']['teacher_calls'],
        'restart_both_stages_teacher_calls':a+fresh_calls,
        'single_suffix_each_calls':records['single_suffix_each']['cost']['teacher_calls'],
        'separate_calls':sum(x['calls'] for x in separate),'separate_dimensions':sum(x['dimension'] for x in separate),
        'new_dimension':v2.dimension,'all_certificates_passed':True,
        'initial_sparse_seed_is_authored':'empty output tests plus one first-symbol test on the first task',
        'note':'warm has answered the first-stage workload before stage two; fresh-all-six alone has not. Both extraction ledgers are reported, not a universal break-even claim.',
        'cost_exclusions':'wall time is in timings.json; reference certification, human design, metadata retrieval and family-aware construction are not included in teacher-call count'}
    dump(out/'summary.json',summary)
    # Full queries retain which arm actually requested each row (including reused).
    keys=sorted(set().union(*(set(x) for x in caches.values())))
    rows=[]
    for j,word in keys:
        arm_values={arm:cache[(j,word)] for arm,cache in caches.items() if (j,word) in cache}
        if len(set(arm_values.values()))!=1:raise AssertionError('inconsistent source')
        rows.append({'task':j,'word':word,'value':next(iter(arm_values.values())),'arms':sorted(arm_values)})
    with gzip.GzipFile(filename=str(out/'teacher_queries.jsonl.gz'),mode='wb',mtime=0) as g:
        for row in rows:g.write((json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode())
    dump(out/'timings.json',{'seconds':times,'warning':'single-run local diagnostics, not a speed benchmark'})
    print(json.dumps(summary,indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',required=True,type=Path)
    run(p.parse_args().out)
