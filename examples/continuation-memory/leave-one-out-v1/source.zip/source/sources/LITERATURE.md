# Selective primary-source research

All links checked on **14 October 2026**. No paper implementations or external datasets were executed. No paper PDFs are redistributed. This is a focused comparison, not an exhaustive novelty search. The new prototype is an application of established ideas with an explicit Zenith evidence trail.

## [1] Multiplicity automata and observation rank

Amos Beimel, Francesco Bergadano, Nader H. Bshouty, Eyal Kushilevitz and Stefano Varricchio. **Learning functions represented as multiplicity automata.** *Journal of the ACM* 47(3), 506–530, 2000. DOI: **10.1145/337244.337257**.

Publisher: https://dl.acm.org/doi/10.1145/337244.337257  
Author institutional record: https://www.bgu.ac.il/en/researcher/amos-beimel/publications/316600033/  
Co-author institutional abstract: https://cris.technion.ac.il/en/publications/learning-functions-represented-as-multiplicity-automata/

Relevant established idea: learning a finite-rank series with membership and equivalence queries, with the Hankel rank characterising minimal linear realisation. The original bibliographic record and institutional abstract were checked; the detailed derivation was read in [2]. No claim is made to have reproduced the original paper's experiments or all complexity results. Some institutional metadata duplicates Kushilevitz; the author list above follows the original citation as reproduced in [2].

## [2] Exact weighted-automaton construction and refinement

**Exactly Learning Weighted Automata over a Field.** Three-page lecture notes hosted by James Worrell, University of Oxford; the PDF itself is undated.

https://www.cs.ox.ac.uk/people/james.worrell/MA-learning.pdf

All three pages were read, including rendered mathematical notation. Pages 1–2 give an invertible observation submatrix and transition equations; pages 2–3 show how a counterexample gives a rank-increasing test. The notes attribute the algorithm to [1]. Our adaptation uses multiple output programmes and finite challenge lists, not a genuine equivalence oracle. Our separate certificate establishes agreement only with a supplied formal reference. No guarantee from the equivalence-query setting is silently transferred to open-world observations.

## [3] State as testable future consequences

Michael L. Littman, Richard S. Sutton and Satinder Singh. **Predictive Representations of State.** *Advances in Neural Information Processing Systems 14*, 2001 conference.

Landing page: https://papers.nips.cc/paper/1983-predictive-representations-of-state  
Original paper: https://papers.neurips.cc/paper/1983-predictive-representations-of-state.pdf

Relevant idea: represent state using predictions of observable future tests rather than an assumed hidden-state identity. The original PDF includes Singh even though the landing-page metadata is incomplete. Our deterministic rational coordinates are programme answers, not probabilistic predictions or a reproduction of the paper's learning results.

## [4] Structure-based library extraction

Matthew Bowers and colleagues. **Top-Down Synthesis for Library Learning.** *Proceedings of the ACM on Programming Languages*, POPL 2023. DOI: **10.1145/3571234**; arXiv:2211.16605.

https://arxiv.org/abs/2211.16605  
https://arxiv.org/html/2211.16605v2

Stitch builds reusable abstractions by corpus-guided synthesis and shared programme structure. Its compression objective is a serious alternative to behavioural-interface extraction, but compressivity alone does not answer this packet's later-use cost question. No quantitative comparison with Stitch was executed here; performance numbers from its evaluation are not imported into our results.

## [5] Library acquisition and documentation

Gabriel Grand, Lionel Wong, Maddy Bowers, Theo X. Olausson, Muxin Liu, Joshua B. Tenenbaum and Jacob Andreas. **LILO: Learning Interpretable Libraries by Compressing and Documenting Code.** ICLR 2024; arXiv:2310.19791.

https://arxiv.org/abs/2310.19791  
https://arxiv.org/html/2310.19791v4

LILO combines programme synthesis, symbolic compression and natural-language documentation to facilitate later use. Documentation is pertinent to node/context design, but readable names and docstrings do not establish the scope or semantic compatibility of a composition. This return compares mechanisms, not benchmark scores, and does not run LILO.

## [6] Abstraction modulo equations

David Cao, Rose Kunkel, Chandrakana Nandi, Max Willsey, Zachary Tatlock and Nadia Polikarpova.

**babble: Learning Better Abstractions with E-Graphs and Anti-Unification.** POPL 2023; arXiv:2212.04596; DOI: **10.1145/3571207**.

https://arxiv.org/abs/2212.04596

The relevant comparison is abstraction extraction using e-graphs and anti-unification, with semantic equivalences supplied through an equational theory. Our execution-based tests can distinguish behaviour without source-text commonality, but the linear representation class is likewise an authored bias. Neither route discovers a universal ontology simply by producing a library.

## [7] Libraries that support subsequent search

Kevin Ellis and colleagues. **DreamCoder: Growing generalizable, interpretable knowledge with wake-sleep Bayesian program learning.** arXiv:2006.08381; corresponding PLDI 2021 paper, DOI: **10.1145/3453483.3454080**.

https://arxiv.org/abs/2006.08381  
https://dl.acm.org/doi/10.1145/3453483.3454080

DreamCoder is an antecedent for learning libraries that help later programme synthesis. The relevant standard for Zenith is an observable improvement in later work, not merely the presence of a new function. Our symbolic state learner does not implement DreamCoder's recognition learning or wake–sleep mechanism.

## [8] Current evidence on compute and actual reuse

Ian Berlot-Attwell, Tobias Sesterhenn, Frank Rudzicz and Xujie Si. **Is This LLM Library Learning? Evaluation Must Account For Compute and Behaviour.** *EACL 2026*, 3534–3568. DOI: **10.18653/v1/2026.eacl-long.163**.

https://aclanthology.org/2026.eacl-long.163/  
https://aclanthology.org/2026.eacl-long.163.pdf

The abstract and relevant introduction/method discussion were inspected. The authors examine three systems and report that advantages fail to hold consistently against simple equal-compute baselines, alongside behavioural doubts about reuse. This is not an impossibility theorem for library learning. It is a directly relevant reason to retain our ordinary controls and distinguish acquisition, actual use and full cost.

The earlier related paper, **Library Learning Doesn't: The Curious Case of the Single-Use “Library”** (Berlot-Attwell, Rudzicz and Si, 2024), was also checked: https://arxiv.org/abs/2410.20274. The 2026 study is the more current citation used in the argument.

## Recent research checked but not used as a claimed advance

**SMT-Based Active Learning of Weighted Automata**, arXiv:2605.07758v2, 23 September 2026. https://arxiv.org/html/2605.07758v2

Its current source was checked to avoid treating weighted-automaton learning as a dormant or unexplored topic. This prototype neither implements the SMT approach nor claims to improve its bounds. No numerical claim in this return depends on that paper.
